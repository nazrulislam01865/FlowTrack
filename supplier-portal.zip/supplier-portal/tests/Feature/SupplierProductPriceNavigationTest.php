<?php

namespace Tests\Feature;

use App\Models\SupplierCompany;
use App\Models\SupplierResource;
use App\Models\SupplierUser;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SupplierProductPriceNavigationTest extends TestCase
{
    use RefreshDatabase;

    private function supplier(string $name): array
    {
        $company = SupplierCompany::create([
            'reference' => 'SUP-'.$name, 'name' => $name, 'active' => true,
        ]);
        $user = SupplierUser::create([
            'supplier_company_id' => $company->id,
            'name' => $name.' Admin',
            'email' => strtolower($name).'@supplier.example',
            'password' => 'LongValidPassword123!', 'active' => true,
        ]);
        return [$company, $user];
    }

    public function test_guest_is_redirected_to_login_instead_of_seeing_missing_price_page(): void
    {
        $this->get('/products/prices')->assertRedirect('/login');
    }

    public function test_pricing_link_is_in_supplier_sidebar_and_page_keeps_shared_navigation(): void
    {
        [$company, $user] = $this->supplier('Alpha');
        SupplierResource::create([
            'supplier_company_id' => $company->id,
            'type' => 'product', 'status' => 'active',
            'external_reference' => 'FT-P-123',
            'payload' => [
                'name' => 'Alpha Jersey', 'code' => 'SKU-123',
                'supplier_prices' => [['quantity' => 100, 'price' => 2.5]],
            ],
        ]);

        $this->actingAs($user)->get('/')->assertOk()
            ->assertSee('Products &amp; Prices', false)
            ->assertSee('href="'.route('supplier.products.prices').'"', false);

        $this->actingAs($user)->get('/products/prices')->assertOk()
            ->assertSee('Alpha Jersey')->assertSee('SKU-123')
            ->assertSee('Edit prices')->assertSee('1 tier')
            ->assertDontSee('Propose new supplier price tiers')
            ->assertSee('Dashboard')->assertSee('Products &amp; Prices', false)
            ->assertDontSee('Customer selling price:');
    }

    public function test_supplier_price_page_does_not_include_other_company_products(): void
    {
        [$alpha, $alice] = $this->supplier('Alpha');
        [$beta] = $this->supplier('Beta');
        foreach ([[$alpha, 'Alpha Product'], [$beta, 'Private Beta Product']] as [$company, $name]) {
            SupplierResource::create([
                'supplier_company_id' => $company->id,
                'type' => 'product', 'status' => 'active',
                'external_reference' => 'FT-P-'.$company->id,
                'payload' => ['name' => $name, 'supplier_prices' => []],
            ]);
        }

        $this->actingAs($alice)->get('/products/prices')->assertOk()
            ->assertSee('Alpha Product')->assertDontSee('Private Beta Product');
    }

    public function test_edit_prices_requires_same_supplier_and_list_filters_before_pagination(): void
    {
        [$alpha, $alice] = $this->supplier('Alpha');
        [$beta] = $this->supplier('Beta');
        $own = SupplierResource::create([
            'supplier_company_id' => $alpha->id, 'type' => 'product', 'status' => 'active',
            'external_reference' => 'FT-P-901',
            'payload' => ['name' => 'Searchable Jersey', 'code' => 'JER-901',
                'supplier_prices' => [['quantity' => 50, 'price' => 3.75]],
                'price_version' => str_repeat('a', 64)],
        ]);
        $other = SupplierResource::create([
            'supplier_company_id' => $beta->id, 'type' => 'product', 'status' => 'active',
            'external_reference' => 'FT-P-902',
            'payload' => ['name' => 'Searchable Competitor', 'code' => 'CP-902'],
        ]);
        $this->actingAs($alice)->get('/products/prices?q=JER-901')->assertOk()
            ->assertSee('Searchable Jersey')->assertDontSee('Searchable Competitor');
        $this->actingAs($alice)->get('/products/prices?q=NO-MATCH')->assertOk()
            ->assertDontSee('Searchable Jersey')->assertSee('No assigned products match');
        $this->actingAs($alice)->get('/products/prices/'.$own->id.'/edit')->assertOk()
            ->assertSee('Current approved supplier tiers')->assertSee('3.75')
            ->assertSee('Request price approval');
        $this->actingAs($alice)->get('/products/prices/'.$other->id.'/edit')->assertNotFound();
        $this->actingAs($alice)->post('/products/prices/'.$other->id, ['prices' => '100 1.20'])
            ->assertNotFound();
    }
}
