<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>Edit Supplier Prices · FlowTrack Supplier Portal</title>
<link rel="stylesheet" href="{{ asset('assets/supplier.css') }}?v={{ filemtime(public_path('assets/supplier.css')) }}">
<style>
.sp-container{width:100%;min-width:0}.sp-header{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:24px}.sp-card{background:#fff;border:1px solid #dce4e9;border-radius:10px;padding:22px;margin-bottom:15px;display:grid;grid-template-columns:1fr 1fr;gap:20px}.sp-tier{font-variant-numeric:tabular-nums;padding:4px 0}.sp-card textarea{width:100%;min-height:120px;border:1px solid #c8d2da;padding:10px;border-radius:5px;font:inherit}.sp-card label{display:block;font-weight:650;margin-bottom:8px}.sp-status{font-size:13px;color:#526876}.sp-notice{padding:14px;background:#eaf6ef;margin-bottom:18px}.sp-error{color:#a82432;margin-bottom:18px}.sp-content{width:100%;min-width:0}@media(max-width:750px){.sp-card{grid-template-columns:1fr}}
</style>
</head>
<body>
<section id="portalView" data-catalog-revision="{{ (string) $company->catalog_revision }}"
    data-catalog-supplier="{{ (int) $company->flowtrack_supplier_id }}"
    data-catalog-key="{{ (string) config('supplier_realtime.key') }}"
    data-catalog-host="{{ (string) config('supplier_realtime.host') }}"
    data-catalog-port="{{ (int) config('supplier_realtime.port') }}"
    data-catalog-scheme="{{ (string) config('supplier_realtime.scheme') }}"
    data-catalog-auth="{{ route('supplier.products.prices.realtime.auth') }}"
    data-catalog-revision-url="{{ route('supplier.products.prices.realtime.revision') }}">
    <header class="topbar">
        <div class="topbar-left">
            <button class="btn btn-ghost btn-sm mobile-menu" id="mobileMenuBtn" aria-label="Open menu" type="button">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
            </button>
            <a class="brand" href="{{ route('supplier.home') }}"><span class="brand-mark"><span class="brand-dot"></span></span>FlowTrack</a>
            <div class="portal-label">Supplier portal</div>
        </div>
        <div class="topbar-right">
            <span class="sync-state"><span class="sync-dot"></span>Secure supplier session</span>
            <a class="notification-btn" href="{{ route('supplier.home') }}?view=notifications" aria-label="Notifications">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg>
            </a>
            <div class="account">
                <div class="avatar">{{ strtoupper(substr(request()->user()->name, 0, 1)) }}</div>
                <div class="account-meta"><strong>{{ request()->user()->name }}</strong><small>{{ $company->name }}</small></div>
                <a class="icon-button" href="{{ route('supplier.home') }}?view=profile" aria-label="Company profile">
                    <svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m6 9 6 6 6-6"/></svg>
                </a>
            </div>
        </div>
    </header>
    <div class="shell">
        @include('portal.partials.sidebar', ['isProductPrices' => true])
        <main class="main"><div class="content sp-content">
            <div class="sp-container">
                <header class="page-header">
                    <div><h1>Edit Supplier Prices</h1><p>Submit a change for approval. Active prices remain unchanged until FlowTracker approves.</p></div>
                    <a class="btn btn-outline-teal btn-sm" href="{{ route('supplier.products.prices') }}">Back to products</a>
                </header>
@if(session('success'))<div class="sp-notice" role="status">{{ session('success') }}</div>@endif
@if($errors->any())<div class="sp-error" role="alert">{{ $errors->first() }}</div>@endif
    @php($payload = $product->payload ?? [])
    <article class="sp-card">
        <div><h2 style="font-size:19px;margin:0 0 8px">{{ $payload['name'] ?? $product->external_reference }}</h2>
            <p class="sp-status">{{ $payload['code'] ?? '' }}</p>
            <h3 style="font-size:14px;margin:16px 0 8px">Current approved supplier tiers</h3>
            @forelse(($payload['supplier_prices'] ?? []) as $tier)
                <div class="sp-tier">Quantity {{ number_format((int)$tier['quantity']) }} → {{ number_format((float)$tier['price'], 2) }}</div>
            @empty <p class="sp-status">No approved prices configured yet.</p> @endforelse
            @if($latest)
                <p style="margin-top:14px"><strong>Latest request: {{ ucfirst($latest->status) }}</strong>
                <span class="sp-status">({{ $latest->delivery_status === 'delivered' ? 'received by FlowTracker' : 'awaiting delivery' }})</span></p>
                @if($latest->review_note)<p class="sp-status">{{ $latest->review_note }}</p>@endif
            @endif
        </div>
        <div>
            @if($latest?->status === 'pending')
                <p class="sp-status">A price revision is already awaiting FlowTracker approval. You can submit another revision once it is reviewed.</p>
            @else
                <form method="post" action="{{ route('supplier.products.prices.submit', $product->id) }}">
                    @csrf
                    <label for="price-{{ $product->id }}">Propose new supplier price tiers</label>
                    <textarea id="price-{{ $product->id }}" name="prices" maxlength="10000" required placeholder="Quantity  Price&#10;100  2.50&#10;500  2.15">@foreach(($payload['supplier_prices'] ?? []) as $tier){{ $tier['quantity'] }} {{ rtrim(rtrim(number_format((float)$tier['price'], 6, '.', ''), '0'), '.') }}{{ !$loop->last ? "\n" : '' }}@endforeach</textarea>
                    <p class="sp-status">One row per quantity tier. No active price changes until FlowTracker approves.</p>
                    <button class="btn btn-primary" type="submit">Request price approval</button>
                </form>
            @endif
        </div>
    </article>
</div>
        </div>
    </main>
  </div>
</section>
<script nonce="{{ request()->attributes->get('csp_nonce') }}">
(function () {
    var button = document.getElementById('mobileMenuBtn');
    var sidebar = document.getElementById('sidebar');
    if (button && sidebar) button.addEventListener('click', function () { sidebar.classList.toggle('open'); });
})();
</script>
<script src="{{ asset('assets/supplier-catalog-realtime.js') }}?v={{ filemtime(public_path('assets/supplier-catalog-realtime.js')) }}" defer nonce="{{ request()->attributes->get('csp_nonce') }}"></script>
</body></html>
