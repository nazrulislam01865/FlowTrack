<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>Products &amp; Prices · FlowTrack Supplier Portal</title>
<link rel="stylesheet" href="{{ asset('assets/supplier.css') }}?v={{ filemtime(public_path('assets/supplier.css')) }}">
<style>
/* Pricing screens reuse the Portal dashboard's normal content width and components. */
.supplier-products .pricing-search { display:flex; width:100%; align-items:center; gap:10px; flex-wrap:wrap; }
.supplier-products .pricing-search .search-wrap { width:min(510px,100%); flex:1 1 260px; }
.supplier-products .pricing-search .search-wrap input { width:100%; padding-left:13px; }
.supplier-products .pricing-product-name { color:#233650; font-weight:700; overflow-wrap:anywhere; }
.supplier-products .pricing-product-code { color:#8491a4; font-size:11px; margin-top:4px; }
.supplier-products .pricing-price-summary { font-variant-numeric:tabular-nums; }
.supplier-products .pricing-price-summary small { display:block; margin-top:5px; color:#8491a4; }
.supplier-products .pricing-actions { text-align:right; white-space:nowrap; }
.supplier-products .pricing-empty { padding:30px 15px; text-align:center; color:#607187; }
.supplier-products .pricing-message { padding:13px 15px; margin-bottom:14px; border:1px solid #cce6d9; border-radius:10px; background:#eff9f4; }
.supplier-products .pricing-message--error { border-color:#e9c6c8; background:#fff3f4; color:#a82432; }
.supplier-products .pricing-pager { margin-top:16px; }
.supplier-products .pricing-pager nav { max-width:100%; }
.supplier-products .pricing-muted { color:#64748b; }
.supplier-products .pricing-status { display:inline-flex; padding:5px 9px; border:1px solid #dce3ea; border-radius:7px; background:#f8fafc; font-size:11px; font-weight:650; white-space:nowrap; }
.supplier-products .pricing-status--pending { color:#9b681b; border-color:#f4deb4; background:#fff9eb; }
.supplier-products .pricing-status--approved { color:#127965; border-color:#cbe8dd; background:#eff9f4; }
.supplier-products .pricing-status--rejected,.supplier-products .pricing-status--stale { color:#a82432; border-color:#f0d1d4; background:#fff3f4; }
.supplier-products .pricing-table { width:100%; table-layout:auto; }
.supplier-products .pricing-table th,.supplier-products .pricing-table td { vertical-align:middle; }
.supplier-products .pricing-table th:last-child { text-align:right; }
@media (max-width:700px) { .supplier-products .pricing-search .btn { flex:0 0 auto; } .supplier-products .pricing-table { min-width:700px; } }
</style>
</head>
<body>
<section id="portalView" data-catalog-revision="{{ (string) $company->catalog_revision }}"
    data-catalog-supplier="{{ (int) $company->flowtrack_supplier_id }}"
    data-catalog-key="{{ (string) config('supplier_realtime.key') }}"
    data-catalog-host="{{ (string) config('supplier_realtime.host') }}"
    data-catalog-port="{{ (int) config('supplier_realtime.port') }}"
    data-catalog-scheme="{{ (string) config('supplier_realtime.scheme') }}"
    data-catalog-auth="{{ route('supplier.products.prices.realtime.auth') }}"
    data-catalog-revision-url="{{ route('supplier.products.prices.realtime.revision') }}">
    <header class="topbar">
        <div class="topbar-left">
            <button class="btn btn-ghost btn-sm mobile-menu" id="mobileMenuBtn" aria-label="Open menu" type="button">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
            </button>
            <a class="brand" href="{{ route('supplier.home') }}"><span class="brand-mark"><span class="brand-dot"></span></span>FlowTrack</a>
            <div class="portal-label">Supplier portal</div>
        </div>
        <div class="topbar-right">
            <span class="sync-state"><span class="sync-dot"></span>Secure supplier session</span>
            <a class="notification-btn" href="{{ route('supplier.home') }}?view=notifications" aria-label="Notifications">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg>
            </a>
            <div class="account">
                <div class="avatar">{{ strtoupper(substr(request()->user()->name, 0, 1)) }}</div>
                <div class="account-meta"><strong>{{ request()->user()->name }}</strong><small>{{ $company->name }}</small></div>
                <a class="icon-button" href="{{ route('supplier.home') }}?view=profile" aria-label="Company profile">
                    <svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m6 9 6 6 6-6"/></svg>
                </a>
            </div>
        </div>
    </header>
    <div class="shell">
        @include('portal.partials.sidebar', ['isProductPrices' => true])
        <main class="main">
            <div class="content supplier-products">
                <header class="page-header">
                    <div><h1>Products &amp; Prices</h1><p>Products assigned to your company and their approved supplier costs. Customer prices are never shared.</p></div>
                    <a class="btn btn-outline-teal btn-sm" href="{{ route('supplier.home') }}">Back to dashboard</a>
                </header>
                @if(session('success'))<div class="pricing-message" role="status">{{ session('success') }}</div>@endif
                @if($errors->any())<div class="pricing-message pricing-message--error" role="alert">{{ $errors->first() }}</div>@endif
                <div class="toolbar">
                    <form class="pricing-search" method="get" action="{{ route('supplier.products.prices') }}" role="search">
                        <label for="productSearch" class="sr-only">Find a product</label>
                        <div class="search-wrap"><input id="productSearch" name="q" value="{{ $search }}" maxlength="100" placeholder="Search product name or code" autocomplete="off"></div>
                        <button class="btn btn-primary btn-sm" type="submit">Search</button>
                        @if($search !== '')<a class="btn btn-outline-teal btn-sm" href="{{ route('supplier.products.prices') }}">Clear</a>@endif
                    </form>
                </div>
                <div class="table-card"><div class="table-scroll">
                    <table class="pricing-table">
                        <thead><tr><th>Product</th><th>Current supplier price tiers</th><th>Latest request</th><th>Action</th></tr></thead>
                        <tbody>
                        @forelse($products as $product)
                            @php($payload = $product->payload ?? [])
                            @php($tiers = $payload['supplier_prices'] ?? [])
                            @php($latest = $proposals->get($product->id))
                            <tr>
                                <td><div class="pricing-product-name">{{ $payload['name'] ?? $product->external_reference }}</div><div class="pricing-product-code">{{ $payload['code'] ?? $product->external_reference }}</div></td>
                                <td class="pricing-price-summary">
                                    @if(is_array($tiers) && count($tiers))
                                        <strong>{{ count($tiers) }} {{ count($tiers) === 1 ? 'tier' : 'tiers' }}</strong>
                                        <small>From {{ number_format((int) ($tiers[0]['quantity'] ?? 0)) }} units · {{ number_format((float) ($tiers[0]['price'] ?? 0), 2) }}</small>
                                    @else <span class="pricing-muted">No approved price yet</span> @endif
                                </td>
                                <td>@if($latest)<span class="pricing-status pricing-status--{{ $latest->status }}">{{ ucfirst($latest->status) }}</span>@else<span class="pricing-muted">No requests</span>@endif</td>
                                <td class="pricing-actions"><a class="btn btn-outline-teal btn-sm" href="{{ route('supplier.products.prices.edit', $product->id) }}">{{ $latest?->status === 'pending' ? 'View request' : 'Edit prices' }}</a></td>
                            </tr>
                        @empty <tr><td colspan="4"><div class="pricing-empty">{{ $search !== '' ? 'No assigned products match your search.' : 'No products are currently assigned to your company.' }}</div></td></tr> @endforelse
                        </tbody>
                    </table>
                </div></div>
                <div class="pricing-pager">{{ $products->withQueryString()->links() }}</div>
            </div>
    </main>
  </div>
</section>
<script nonce="{{ request()->attributes->get('csp_nonce') }}">
(function () {
    var button = document.getElementById('mobileMenuBtn');
    var sidebar = document.getElementById('sidebar');
    if (button && sidebar) button.addEventListener('click', function () { sidebar.classList.toggle('open'); });
})();
</script>
<script src="{{ asset('assets/supplier-catalog-realtime.js') }}?v={{ filemtime(public_path('assets/supplier-catalog-realtime.js')) }}" defer nonce="{{ request()->attributes->get('csp_nonce') }}"></script>
</body></html>
