<div class="supplier-prototype-recent-item is-<?php echo e($update['status']); ?>">
    <div class="supplier-prototype-recent-dot"><span></span></div>
    <div class="supplier-prototype-recent-copy">
        <strong><?php echo e($update['title']); ?></strong>
        <span><?php echo e($update['date']); ?></span>
        <?php if(filled($update['description'])): ?><p><?php echo e($update['description']); ?></p><?php endif; ?>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/FlowTracker/supplier-portal/resources/views/portal/order/partials/recent-update.blade.php ENDPATH**/ ?>