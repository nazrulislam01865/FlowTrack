<?php

namespace App\Http\Controllers\Integration;

use App\Models\SupplierCompany;
use App\Models\SupplierResource;
use App\Models\SupplierPriceProposal;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

/** FlowTracker is the sole authority for supplier identity and product assignments. */
final class SyncFlowtrackSupplier extends Controller
{
    use VerifiesFlowtrack;

    public function __invoke(Request $request): JsonResponse
    {
        $data = $this->signedData($request);
        if ($data === null) return response()->json(['message' => 'Unauthorized.'], 401);
        $validator = Validator::make($data, [
            'supplier_id' => ['required', 'integer', 'min:1'],
            'catalog_revision' => ['required', 'integer', 'min:1'],
            'reference' => ['required', 'string', 'max:80'],
            'name' => ['required', 'string', 'max:255'],
            'short_code' => ['required', 'string', 'max:40'],
            'active' => ['required', 'boolean'],
            'products' => ['present', 'array', 'max:2000'],
            'products.*.id' => ['required', 'integer', 'min:1', 'distinct'],
            'products.*.code' => ['required', 'string', 'max:120'],
            'products.*.name' => ['required', 'string', 'max:255'],
            'products.*.active' => ['required', 'boolean'],
            'products.*.supplier_prices' => ['present', 'array', 'max:100'],
            'products.*.supplier_prices.*.quantity' => ['required', 'integer', 'min:1'],
            'products.*.supplier_prices.*.price' => ['required', 'numeric', 'min:0'],
            'products.*.price_version' => ['required', 'regex:/^[a-f0-9]{64}$/'],
            'decisions' => ['sometimes', 'array', 'max:500'],
            'decisions.*.request_uuid' => ['required', 'uuid'],
            'decisions.*.status' => ['required', 'in:approved,rejected,stale'],
            'decisions.*.review_note' => ['nullable', 'string', 'max:500'],
        ]);
        if ($validator->fails()) {
            // Signed integration callers may inspect invalid field paths, never the submitted values.
            return response()->json([
                'message' => 'Invalid supplier catalogue.',
                'invalid_fields' => array_slice($validator->errors()->keys(), 0, 20),
            ], 422);
        }

        $id = (int) $data['supplier_id'];
        $result = DB::transaction(function () use ($id, $data): SupplierCompany {
            $company = SupplierCompany::query()->where('flowtrack_supplier_id', $id)->lockForUpdate()->first();
            if (! $company) {
                // Never implicitly take over an existing, independently invited account.
                $company = SupplierCompany::create([
                    'flowtrack_supplier_id' => $id, 'reference' => $data['reference'],
                    'name' => $data['name'], 'flowtrack_short_code' => $data['short_code'], 'active' => $data['active'],
                ]);
            }
            if ((int) $data['catalog_revision'] < (int) ($company->catalog_revision ?? 0)) {
                return $company; // Ignore out-of-order catalogue deliveries.
            }
            $company->fill(['name' => $data['name'], 'active' => $data['active'],
                'flowtrack_short_code' => $data['short_code']]);
            $company->catalog_revision = (int) $data['catalog_revision'];
            $company->save();
            $now = now();
            $rows = [];
            $references = [];
            foreach ($data['products'] as $product) {
                $ref = 'FT-P-'.$product['id'];
                $references[] = $ref;
                $rows[] = [
                    'supplier_company_id' => $company->id, 'type' => 'product',
                    'external_reference' => $ref,
                    'status' => $product['active'] ? 'active' : 'inactive',
                    'payload' => json_encode(['code' => $product['code'], 'name' => $product['name'], 'supplier_prices' => $product['supplier_prices'], 'price_version' => $product['price_version']], JSON_THROW_ON_ERROR),
                    'created_at' => $now, 'updated_at' => $now,
                ];
            }
            foreach (array_chunk($rows, 250) as $chunk) {
                SupplierResource::query()->upsert($chunk, ['supplier_company_id', 'type', 'external_reference'], ['status', 'payload', 'updated_at']);
            }
            $stale = SupplierResource::query()->where('supplier_company_id', $company->id)
                ->where('type', 'product')->where('external_reference', 'like', 'FT-P-%');
            if ($references !== []) $stale->whereNotIn('external_reference', $references);
            // Keep proposal audit when FlowTracker removes a product assignment.
            $staleIds = (clone $stale)->pluck('id');
            if ($staleIds->isNotEmpty()) {
                SupplierPriceProposal::query()->where('supplier_company_id', $company->id)
                    ->whereIn('supplier_resource_id', $staleIds)->where('status', 'pending')
                    ->update(['status' => 'stale', 'review_note' => 'Product assignment was removed.']);
            }
            $stale->delete();
            foreach ($data['decisions'] ?? [] as $decision) {
                SupplierPriceProposal::query()->where('supplier_company_id', $company->id)
                    ->where('request_uuid', $decision['request_uuid'])->where('status', 'pending')
                    ->update(['status' => $decision['status'], 'delivery_status' => 'delivered',
                        'review_note' => $decision['review_note'] ?? null]);
            }
            return $company;
        });
        return response()->json(['synced' => true, 'supplier_id' => $id, 'company_id' => $result->id]);
    }
}
