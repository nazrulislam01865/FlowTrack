<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Validation\Rules\Password as PasswordRule;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function loginForm() { return view('auth.login'); }

    public function login(Request $request)
    {
        $credentials = $request->validate(['email'=>['required','string','max:254'], 'password'=>['required','string'], 'remember'=>['nullable','boolean']]);
        $identifier = Str::lower(trim($credentials['email']));
        $field = filter_var($identifier, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
        $ok = Auth::attempt([$field=>$identifier, 'password'=>$credentials['password'], 'active'=>true], (bool) ($credentials['remember'] ?? false));
        if (!$ok || !Auth::user()?->company?->active) {
            Auth::logout();
            throw ValidationException::withMessages(['email'=>'These credentials do not match an active supplier account.']);
        }
        $request->session()->regenerate();
        if ($request->user()->must_change_password) return redirect()->route('supplier.password.change');
        return redirect()->intended(route('supplier.home'));
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('supplier.login');
    }

    public function forgotForm() { return view('auth.forgot'); }

    public function sendReset(Request $request)
    {
        $request->validate(['email'=>['required','email','max:254']]);
        // Never disclose whether an email exists in this invitation-only application.
        Password::broker('supplier_users')->sendResetLink(['email'=>Str::lower(trim($request->email))]);
        return back()->with('status','If this address has an active supplier account, a reset link has been sent.');
    }

    public function resetForm(Request $request, string $token)
    {
        return view('auth.reset', ['token'=>$token, 'email'=>$request->query('email', '')]);
    }

    public function resetPassword(Request $request)
    {
        $data = $request->validate([
            'token'=>['required','string'], 'email'=>['required','email'],
            'password'=>['required','confirmed', PasswordRule::min(8)],
        ]);
        $status = Password::broker('supplier_users')->reset($data, function ($user, $password) {
            if (!$user->active || !$user->company?->active) return;
            $user->forceFill(['password'=>Hash::make($password),'remember_token'=>Str::random(60),'must_change_password'=>false])->save();
            event(new PasswordReset($user));
        });
        if ($status !== Password::PASSWORD_RESET) {
            return back()->withErrors(['email'=>'This reset link is invalid or expired.']);
        }
        return redirect()->route('supplier.login')->with('status','Your password has been updated.');
    }
    /** Forced password change after an administrator issues a temporary password. */
    public function changeRequiredForm()
    {
        return view('auth.change-password');
    }

    public function changeRequiredPassword(Request $request)
    {
        $data = $request->validate([
            'current_password' => ['required', 'current_password:web'],
            'password' => ['required', 'confirmed', 'different:current_password', PasswordRule::min(8)],
        ]);
        $user = $request->user();
        $user->forceFill([
            'password' => Hash::make($data['password']),
            'must_change_password' => false,
            'remember_token' => Str::random(60),
        ])->save();
        $request->session()->regenerate();
        return redirect()->route('supplier.home')->with('status', 'Password changed successfully.');
    }
}
