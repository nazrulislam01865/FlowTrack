<?php

namespace App\Http\Controllers;

use App\Models\SupplierPriceProposal;
use App\Models\SupplierResource;
use App\Services\FlowtrackPriceProposalDelivery;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

final class SupplierProductPriceController extends Controller
{
    public function index(Request $request)
    {
        $company = $request->user()->company;
        $companyId = (int) $company->id;
        $search = trim((string) $request->query('q', ''));
        $search = mb_substr($search, 0, 100);
        $query = SupplierResource::query()->where('supplier_company_id', $companyId)
            ->where('type', 'product')->where('status', 'active');
        if ($search !== '') {
            // Filter in SQL before pagination; all matches remain supplier-scoped.
            $term = '%'.addcslashes($search, '%_\\').'%';
            $query->where(function ($match) use ($term): void {
                $match->where('external_reference', 'like', $term)
                    ->orWhere('payload->name', 'like', $term)
                    ->orWhere('payload->code', 'like', $term);
            });
        }
        $products = $query->orderBy('id')->paginate(20, ['id', 'external_reference', 'payload']);
        $latestIds = SupplierPriceProposal::query()->where('supplier_company_id', $companyId)
            ->whereIn('supplier_resource_id', $products->pluck('id'))
            ->selectRaw('MAX(id)')->groupBy('supplier_resource_id');
        $proposals = SupplierPriceProposal::query()->whereIn('id', $latestIds)
            ->get()->keyBy('supplier_resource_id');
        return view('portal.product-prices', compact('products', 'proposals', 'company', 'search'));
    }

    public function edit(Request $request, int $id)
    {
        $company = $request->user()->company;
        $product = SupplierResource::query()->where('supplier_company_id', $company->id)
            ->where('type', 'product')->where('status', 'active')->findOrFail($id);
        $latest = SupplierPriceProposal::query()->where('supplier_company_id', $company->id)
            ->where('supplier_resource_id', $product->id)->latest('id')->first();
        return view('portal.product-price-edit', compact('company', 'product', 'latest'));
    }

    public function submit(Request $request, int $id, FlowtrackPriceProposalDelivery $delivery): RedirectResponse
    {
        $data = $request->validate(['prices' => ['required', 'string', 'max:10000']]);
        $rows = $this->parseRows($data['prices']);
        $companyId = (int) $request->user()->supplier_company_id;
        $proposalId = DB::transaction(function () use ($id, $request, $companyId, $rows): int {
            $product = SupplierResource::query()->where('supplier_company_id', $companyId)
                ->where('type', 'product')->where('status', 'active')->whereKey($id)
                ->lockForUpdate()->firstOrFail();
            $version = $product->payload['price_version'] ?? null;
            if (! is_string($version) || ! preg_match('/^[a-f0-9]{64}$/', $version)) {
                throw ValidationException::withMessages(['prices' => 'Price baseline is not synchronized yet.']);
            }
            if (SupplierPriceProposal::query()->where('supplier_company_id', $companyId)
                ->where('supplier_resource_id', $product->id)->where('status', 'pending')->exists()) {
                throw ValidationException::withMessages(['prices' => 'This product already has a pending price request.']);
            }
            $proposal = SupplierPriceProposal::query()->create([
                'supplier_company_id' => $companyId, 'supplier_resource_id' => $product->id,
                'supplier_user_id' => $request->user()->id, 'request_uuid' => (string) Str::uuid(),
                'base_version' => $version, 'proposed_prices' => $rows,
                'status' => 'pending', 'delivery_status' => 'pending',
            ]);
            return (int) $proposal->id;
        });
        $sent = $delivery->send($proposalId);
        return redirect()->route('supplier.products.prices.edit', $id)->with('success', $sent
            ? 'Price request sent to FlowTracker for approval. The approved prices are unchanged.'
            : 'Price request saved. Secure delivery will retry automatically. The approved prices are unchanged.');
    }

    private function parseRows(string $value): array
    {
        $result = [];
        foreach (preg_split('/\R/', trim($value)) ?: [] as $line) {
            $line = trim($line);
            if ($line === '') continue;
            if (preg_match('/^quantity[\s,;|]+(?:unit\s+)?price$/i', $line)) continue;
            if (! preg_match('/^(\d+)[\t ,;|]+(\d+(?:\.\d{1,6})?)$/', $line, $matches)) {
                throw ValidationException::withMessages(['prices' => 'Enter one quantity and price per row, e.g. 100  2.50.']);
            }
            $quantity = (int) $matches[1];
            $price = (float) $matches[2];
            if ($quantity < 1 || $quantity > 100000000 || $price > 999999999.99 || isset($result[$quantity])) {
                throw ValidationException::withMessages(['prices' => 'Invalid or duplicate quantity/price tier.']);
            }
            $result[$quantity] = ['quantity' => $quantity, 'price' => $price];
            if (count($result) > 100) throw ValidationException::withMessages(['prices' => 'Maximum 100 tiers per product.']);
        }
        if ($result === []) throw ValidationException::withMessages(['prices' => 'Enter at least one price tier.']);
        ksort($result, SORT_NUMERIC);
        return array_values($result);
    }
}
