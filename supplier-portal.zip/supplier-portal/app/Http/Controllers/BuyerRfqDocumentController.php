<?php

namespace App\Http\Controllers;

use App\Services\SupplierScope;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Http;
use Symfony\Component\HttpFoundation\HeaderUtils;

/** Browser access stays company-scoped; document bytes travel over a signed server link. */
final class BuyerRfqDocumentController extends Controller
{
    public function __invoke(Request $request, int $id, int $document, SupplierScope $scope)
    {
        $rfq = $scope->resource($request, $id, 'rfq');
        $manifest = collect($rfq->payload['documents'] ?? [])->first(fn (array $doc): bool => (int) $doc['id'] === $document);
        abort_unless($manifest && (int) ($rfq->payload['invitation_id'] ?? 0) > 0, 404);
        $url = (string) config('flowtrack_bridge.buyer_url');
        $secret = (string) config('flowtrack_bridge.secret');
        $scheme = parse_url($url, PHP_URL_SCHEME);
        $host = parse_url($url, PHP_URL_HOST);
        abort_unless(config('flowtrack_bridge.enabled') && strlen($secret) >= 32 && is_string($host) && $host !== ''
            && ! str_contains($url, '@') && ! str_contains($url, '?') && ! str_contains($url, '#')
            && ($scheme === 'https' || ($scheme === 'http' && app()->environment(['local', 'testing']) && in_array($host, ['localhost', '127.0.0.1'], true))), 503);
        $supplier = (int) $request->user()->company->flowtrack_supplier_id;
        $invitation = (int) $rfq->payload['invitation_id'];
        abort_if($supplier < 1, 404);
        $time = (string) time();
        $response = Http::connectTimeout(2)->timeout(20)->withHeaders([
            'X-FlowTrack-Timestamp' => $time,
            'X-FlowTrack-Supplier' => (string) $supplier,
            'X-FlowTrack-Signature' => hash_hmac('sha256', $time."\n".$supplier."\n".$invitation."\n".$document, $secret),
            'Accept' => 'application/octet-stream',
        ])->withoutRedirecting()->get($url.'/api/supplier-bridge/rfq-documents/'.$invitation.'/'.$document);
        abort_unless($response->successful(), 404);
        $data = $response->body();
        abort_if(strlen($data) > 20971520, 413);
        return response($data, 200, [
            'Content-Type' => 'application/octet-stream',
            'Content-Disposition' => HeaderUtils::makeDisposition(HeaderUtils::DISPOSITION_ATTACHMENT, basename($manifest['name'])),
            'Cache-Control' => 'private, no-store',
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }
}
