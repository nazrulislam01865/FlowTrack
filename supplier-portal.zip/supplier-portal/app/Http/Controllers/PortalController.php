<?php
namespace App\Http\Controllers;

use App\Models\SupplierResource;
use Illuminate\Routing\Controller;
use Illuminate\Http\Request;

class PortalController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        abort_unless($user->active && $user->company?->active, 403);
        $company = $user->company;
        $resources = SupplierResource::query()
            ->where('supplier_company_id', $company->id)
            ->where('type', 'rfq')
            ->with('quotation:id,supplier_resource_id,sync_status,sync_attempts')
            ->orderByRaw("CASE WHEN status IN ('open', 'draft') THEN 0 ELSE 1 END")
            ->orderBy('due_at')->limit(100)->get(['id','external_reference','status','payload','due_at','updated_at']);
        $quotations = $resources->map(function ($resource) {
            $p = $resource->payload;
            return [
                'id'=>$resource->id,
                'product'=>(string) ($p['product_name'] ?? 'Product'),
                'ref'=>$resource->external_reference,
                'code'=>(string) ($p['product_code'] ?? ''),
                'items' => $p['items'] ?? [],
                'documents' => $p['documents'] ?? [],
                'message' => (string) ($p['request_message'] ?? ''),
                'supplierDetails' => (string) ($p['supplier_details'] ?? ''),
                'deliveryDate' => (string) ($p['delivery_date'] ?? ''),
                'currency' => (string) ($p['currency'] ?? 'USD'),
                'inquiryRef'=>(string) ($p['inquiry_reference'] ?? ''),
                'requirements'=>(string) ($p['buyer_requirements'] ?? ''),
                'buyer'=>(string) ($p['buyer_label'] ?? 'Buyer'),
                'qty'=>number_format((float) ($p['quantity'] ?? 0), 2, '.', ',').' units',
                'quantity'=>(float) ($p['quantity'] ?? 0),
                'due'=>$resource->due_at?->format('M j, Y') ?? 'Not set',
                'dueShort'=>$resource->due_at?->format('M j') ?? 'Not set',
                'updated'=>$resource->updated_at?->format('M j, H:i') ?? '',
                'updatedIso' => $resource->updated_at?->toIso8601String() ?? '',
                'status'=>$resource->status,
                'syncStatus'=>$resource->quotation?->sync_status,
                'syncAttempts'=>(int) ($resource->quotation?->sync_attempts ?? 0),
                'urgent'=>$resource->due_at && $resource->due_at->isFuture() && $resource->due_at->diffInDays(now()) <= 3,
            ];
        })->values();
        // Orders are paginated, scoped to the authenticated supplier company.
        // Historical backfills can contain many records; do not load the entire archive.
        $orderPage = SupplierResource::query()
            ->where('supplier_company_id', $company->id)
            ->where('type', 'order')->where('status', '!=', 'revoked')
            ->latest('id')->paginate(50, ['id', 'external_reference', 'status', 'payload', 'due_at', 'created_at'], 'orders_page');
        $orders = $orderPage->getCollection()->map(function (SupplierResource $resource): array {
            $payload = $resource->payload ?? [];
            $originalDate = $payload['created_at'] ?? null;
            try {
                $created = $originalDate ? \Illuminate\Support\Carbon::parse($originalDate)->format('M j, Y') : ($resource->created_at?->format('M j, Y') ?? '');
            } catch (\Throwable $exception) {
                $created = '';
            }
            return [
                'id' => $resource->id,
                'reference' => $resource->external_reference,
                'title' => 'Order '.$resource->external_reference,
                'items' => $payload['items'] ?? [],
                'created' => $created,
                'due' => $resource->due_at?->format('M j, Y') ?? 'Not specified',
                'status' => $resource->status,
                'orderStatus' => (string) ($payload['order_status'] ?? 'New'),
                'approvedArtworkId' => (int) data_get($payload, 'documents.0.id', 0),
            ];
        })->values();
        $profile = $company->profile ?? [];
        $maskedBank = $user->role === 'admin' ? ($company->encrypted_banking ?? []) : [];
        return view('portal.index', compact('user','company','quotations','orders','orderPage','profile','maskedBank'));
    }
}
