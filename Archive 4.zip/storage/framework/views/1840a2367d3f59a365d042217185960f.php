<section
    id="page-<?php echo e($flowtrackPage ?? 'dashboard'); ?>"
    class="page active"
    data-flowtrack-screen="<?php echo e($flowtrackPage ?? 'dashboard'); ?>"
    data-route-page="true"
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/flowtrack/pages/screen.blade.php ENDPATH**/ ?>