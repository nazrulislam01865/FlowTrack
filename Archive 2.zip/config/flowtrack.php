<?php

return [
    'workspace' => [
        'name' => env('FLOWTRACK_WORKSPACE_NAME', 'FlowTrack Workspace'),
        'slug' => env('FLOWTRACK_WORKSPACE_SLUG', 'flowtrack-demo'),
        'timezone' => env('FLOWTRACK_WORKSPACE_TIMEZONE', env('APP_TIMEZONE', 'Asia/Dhaka')),
        'currency' => env('FLOWTRACK_WORKSPACE_CURRENCY', 'USD'),
    ],

    'super_admin' => [
        'name' => env('FLOWTRACK_SUPER_ADMIN_NAME', 'FlowTrack Super Admin'),
        'email' => env('FLOWTRACK_SUPER_ADMIN_EMAIL'),
        'password' => env('FLOWTRACK_SUPER_ADMIN_PASSWORD'),
    ],

    'notification_rules' => [
        ['name' => 'Task due reminder', 'trigger' => '2 days before due', 'recipients' => 'Assignee', 'active' => true],
        ['name' => 'Overdue escalation', 'trigger' => '1 day overdue', 'recipients' => 'Assignee + Manager', 'active' => true],
        ['name' => 'Shipment deadline', 'trigger' => '3 days before ship date', 'recipients' => 'Shipment + Manager', 'active' => true],
        ['name' => 'Invoice due reminder', 'trigger' => '5 days before due', 'recipients' => 'Accounts + Sales', 'active' => true],
        ['name' => 'Blocked task escalation', 'trigger' => 'Immediately', 'recipients' => 'Manager + Job owner', 'active' => true],
    ],

    'administrator_role_codes' => [
        'SUPER_ADMIN',
        'ADMIN',
        'SYS_ADMIN',
        'ADMINISTRATOR',
        'SYSTEM_ADMINISTRATOR',
    ],
];
