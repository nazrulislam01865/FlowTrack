<script>
window.FLOWTRACK_AUTHENTICATED = <?php echo e(Illuminate\Support\Js::from((bool) $flowtrackAuthenticated)); ?>;
window.FLOWTRACK_SESSION = <?php echo e(Illuminate\Support\Js::from($flowtrackSessionConfig ?? [])); ?>;
window.FLOWTRACK_PUSHER = <?php echo e(Illuminate\Support\Js::from($flowtrackPusherConfig ?? [])); ?>;
window.FLOWTRACK_INITIAL_PATH = <?php echo e(Illuminate\Support\Js::from($flowtrackInitialPath ?? ('/'.ltrim(request()->path(), '/')))); ?>;
window.FLOWTRACK_BRANDING = <?php echo e(Illuminate\Support\Js::from($flowtrackBranding ?? [])); ?>;
window.FLOWTRACK_ACTIVE_PAGE = <?php echo e(Illuminate\Support\Js::from($flowtrackPage ?? 'dashboard')); ?>;
window.FLOWTRACK_PAGE_ROUTES = <?php echo e(Illuminate\Support\Js::from($flowtrackPageRoutes ?? [])); ?>;
</script>
<script defer src="<?php echo e(asset('flowtrack/searchable-dropdown.js')); ?>"></script>
<script defer src="<?php echo e(asset('flowtrack/loader.js')); ?>"></script>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flowtrackAuthenticated && filled(config('services.pusher.key'))): ?>
<script
    async
    src="https://js.pusher.com/8.4.0/pusher.min.js"
    onload="window.dispatchEvent(new Event('flowtrack:pusher-ready'))"
></script>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/flowtrack/partials/assets.blade.php ENDPATH**/ ?>