export const build = "274b03bd8130c731";
export const files = Object.freeze({
    "core": "core.js",
    "workspace": "workspace.js",
    "operations": "operations.js",
    "configuration": "configuration.js",
    "records": "records.js",
    "job-shared": "job-shared.js",
    "task-details": "task-details.js",
    "job-details": "job-details.js",
    "board": "board.js"
});
