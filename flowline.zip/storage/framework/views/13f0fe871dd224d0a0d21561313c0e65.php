<section
    id="page-jobs"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="jobs"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/jobs.blade.php ENDPATH**/ ?>