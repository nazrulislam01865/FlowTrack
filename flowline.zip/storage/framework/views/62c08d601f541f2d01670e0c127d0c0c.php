<div id="overlay" class="overlay"></div>
<div id="jobModal" class="modal"></div>
<aside id="detailDrawer" class="drawer"></aside>
<div id="toast" class="toast" aria-live="polite"></div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/flowtrack/partials/overlays.blade.php ENDPATH**/ ?>