<section
    id="page-dashboard"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="dashboard"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/dashboard.blade.php ENDPATH**/ ?>