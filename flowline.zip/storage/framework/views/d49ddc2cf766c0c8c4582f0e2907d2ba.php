<section
    id="page-board"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="board"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/board.blade.php ENDPATH**/ ?>