<section
    id="page-documents"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="documents"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/documents.blade.php ENDPATH**/ ?>