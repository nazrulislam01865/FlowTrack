<section
    id="page-mywork"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="mywork"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/mywork.blade.php ENDPATH**/ ?>