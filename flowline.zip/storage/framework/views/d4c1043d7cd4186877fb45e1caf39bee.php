<script src="<?php echo e(asset('flowtrack-prototype-fallback.js')); ?>?v=<?php echo e(filemtime(public_path('flowtrack-prototype-fallback.js'))); ?>"></script>
<script>
window.FLOWTRACK_AUTHENTICATED = <?php echo e(Illuminate\Support\Js::from((bool) $flowtrackAuthenticated)); ?>;
window.FLOWTRACK_SESSION = <?php echo e(Illuminate\Support\Js::from($flowtrackSessionConfig ?? [])); ?>;
window.FLOWTRACK_PUSHER = <?php echo e(Illuminate\Support\Js::from($flowtrackPusherConfig ?? [])); ?>;
window.FLOWTRACK_INITIAL_PATH = <?php echo e(Illuminate\Support\Js::from($flowtrackInitialPath ?? ('/'.ltrim(request()->path(), '/')))); ?>;
window.FLOWTRACK_BRANDING = <?php echo e(Illuminate\Support\Js::from($flowtrackBranding ?? [])); ?>;
</script>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

<script src="<?php echo e(asset('flowtrack-searchable-dropdown.js')); ?>?v=<?php echo e(filemtime(public_path('flowtrack-searchable-dropdown.js'))); ?>"></script>
<script src="<?php echo e(asset('flowtrack-dynamic.js')); ?>?v=<?php echo e(filemtime(public_path('flowtrack-dynamic.js'))); ?>"></script>
<script src="<?php echo e(asset('flowtrack-livewire.js')); ?>?v=<?php echo e(filemtime(public_path('flowtrack-livewire.js'))); ?>"></script>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($flowtrackAuthenticated && filled(config('services.pusher.key'))): ?>
<script
    async
    src="https://js.pusher.com/8.4.0/pusher.min.js"
    onload="window.dispatchEvent(new Event('flowtrack:pusher-ready'))"
></script>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/flowtrack/partials/assets.blade.php ENDPATH**/ ?>