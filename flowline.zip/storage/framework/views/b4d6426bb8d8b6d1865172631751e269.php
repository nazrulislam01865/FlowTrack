<div id="authLoadingScreen" class="auth-loading <?php echo e($flowtrackAuthenticated ? '' : 'hidden'); ?>" aria-live="polite">
  <div class="card auth-loading-card">
    <b>Loading your FlowTrack workspace</b>
    <div class="auth-progress-meta"><span data-auth-loading-label>Preparing workspace…</span><strong data-auth-loading-percent>0%</strong></div>
    <div class="auth-progress-track"><span data-auth-loading-progress></span></div>
    <div class="small muted auth-loading-help">Jobs, tasks, documents and assignees are loading now.</div>
  </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/flowtrack/auth/loading.blade.php ENDPATH**/ ?>