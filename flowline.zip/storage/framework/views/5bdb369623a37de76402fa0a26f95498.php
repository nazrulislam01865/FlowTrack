<section
    id="page-profile"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="profile"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/profile.blade.php ENDPATH**/ ?>