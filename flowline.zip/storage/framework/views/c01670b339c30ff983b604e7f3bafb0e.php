<section
    id="page-taskpacksetup"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="taskpacksetup"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/taskpacksetup.blade.php ENDPATH**/ ?>