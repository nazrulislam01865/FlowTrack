<section
    id="page-masterdata"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="masterdata"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/masterdata.blade.php ENDPATH**/ ?>