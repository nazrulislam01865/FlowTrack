<section
    id="page-notifications"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="notifications"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/notifications.blade.php ENDPATH**/ ?>