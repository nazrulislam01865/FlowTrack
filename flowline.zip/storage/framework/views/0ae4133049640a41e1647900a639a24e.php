<section
    id="page-clients"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="clients"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/clients.blade.php ENDPATH**/ ?>