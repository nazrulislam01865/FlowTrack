<section
    id="page-workflowsetup"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="workflowsetup"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/workflowsetup.blade.php ENDPATH**/ ?>