<section
    id="page-setup"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="setup"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/setup.blade.php ENDPATH**/ ?>