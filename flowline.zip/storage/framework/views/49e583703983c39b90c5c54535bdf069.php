<section
    id="page-reports"
    class="page <?php echo e($active ? 'active' : ''); ?>"
    data-livewire-screen="reports"
    wire:ignore
></section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/livewire/flow-track/screens/reports.blade.php ENDPATH**/ ?>