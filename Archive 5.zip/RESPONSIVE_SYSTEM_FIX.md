# FlowTrack System-wide Responsive Fix

This update adds a final responsive hardening layer without changing FlowTrack business logic or visual styling.

## Main fixes

- Prevents page-level horizontal overflow across the application shell.
- Jobs filters wrap responsively instead of extending beyond the viewport.
- Operations Board and My Work filters wrap at laptop/tablet/mobile widths.
- Job Board phase columns scroll inside the board on larger screens and keep the existing stacked mobile behavior.
- Task Board horizontal overflow stays inside its board canvas.
- Master Data category navigation changes to a responsive grid on smaller screens.
- Master Data records become tablet/mobile cards so the Actions column is never clipped.
- Setup/Workflow/Task Pack navigation uses responsive grids rather than clipped horizontal strips.
- Shared tables are constrained to their own scroll containers.
- Dashboard, Clients, Documents, Reports, forms, summaries, modals and page action groups receive common shrink/wrap safeguards.
- Mobile bottom navigation is constrained to the viewport.

## Files changed

- `resources/css/flowtrack/app.css`
- `resources/css/flowtrack/runtime/13-system-responsive.css` (new)
- `public/build/assets/app-WVsKJ2_V.css` (prebuilt asset updated for immediate use)

## Future builds

Run:

```bash
npm install
npm run build
```

The source CSS import is already present, so future Vite builds will include the responsive layer automatically.
