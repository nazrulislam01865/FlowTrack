import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import versions from './versions'
/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/flowtrack/documents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::store
* @see app/Http/Controllers/FlowTrack/DocumentController.php:62
* @route '/flowtrack/documents'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/documents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::store
* @see app/Http/Controllers/FlowTrack/DocumentController.php:62
* @route '/flowtrack/documents'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::store
* @see app/Http/Controllers/FlowTrack/DocumentController.php:62
* @route '/flowtrack/documents'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::store
* @see app/Http/Controllers/FlowTrack/DocumentController.php:62
* @route '/flowtrack/documents'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::store
* @see app/Http/Controllers/FlowTrack/DocumentController.php:62
* @route '/flowtrack/documents'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const documents = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    versions: Object.assign(versions, versions),
}

export default documents