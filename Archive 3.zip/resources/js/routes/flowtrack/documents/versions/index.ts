import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
export const download = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/flowtrack/documents/versions/{version}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
download.url = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { version: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { version: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            version: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        version: typeof args.version === 'object'
        ? args.version.id
        : args.version,
    }

    return download.definition.url
            .replace('{version}', parsedArgs.version.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
download.get = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
download.head = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
const downloadForm = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
downloadForm.get = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
downloadForm.head = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

download.form = downloadForm

const versions = {
    download: Object.assign(download, download),
}

export default versions