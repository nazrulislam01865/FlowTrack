import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import jobs from './jobs'
import tasks from './tasks'
/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/flowtrack/board',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const board = {
    index: Object.assign(index, index),
    jobs: Object.assign(jobs, jobs),
    tasks: Object.assign(tasks, tasks),
}

export default board