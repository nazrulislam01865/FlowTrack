import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::store
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:87
* @route '/flowtrack/administration/members'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/administration/members',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::store
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:87
* @route '/flowtrack/administration/members'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::store
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:87
* @route '/flowtrack/administration/members'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::store
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:87
* @route '/flowtrack/administration/members'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::store
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:87
* @route '/flowtrack/administration/members'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::update
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:124
* @route '/flowtrack/administration/members/{membership}'
*/
export const update = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/flowtrack/administration/members/{membership}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::update
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:124
* @route '/flowtrack/administration/members/{membership}'
*/
update.url = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { membership: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { membership: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            membership: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        membership: typeof args.membership === 'object'
        ? args.membership.id
        : args.membership,
    }

    return update.definition.url
            .replace('{membership}', parsedArgs.membership.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::update
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:124
* @route '/flowtrack/administration/members/{membership}'
*/
update.put = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::update
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:124
* @route '/flowtrack/administration/members/{membership}'
*/
const updateForm = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::update
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:124
* @route '/flowtrack/administration/members/{membership}'
*/
updateForm.put = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const members = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
}

export default members