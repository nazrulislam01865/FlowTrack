import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import roles from './roles'
import members from './members'
/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/flowtrack/administration',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const administration = {
    index: Object.assign(index, index),
    roles: Object.assign(roles, roles),
    members: Object.assign(members, members),
}

export default administration