import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import items from './items'
/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:16
* @route '/flowtrack/task-packs'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/task-packs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:16
* @route '/flowtrack/task-packs'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:16
* @route '/flowtrack/task-packs'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:16
* @route '/flowtrack/task-packs'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:16
* @route '/flowtrack/task-packs'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:35
* @route '/flowtrack/task-packs/{taskPack}'
*/
export const update = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/flowtrack/task-packs/{taskPack}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:35
* @route '/flowtrack/task-packs/{taskPack}'
*/
update.url = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskPack: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { taskPack: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            taskPack: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        taskPack: typeof args.taskPack === 'object'
        ? args.taskPack.id
        : args.taskPack,
    }

    return update.definition.url
            .replace('{taskPack}', parsedArgs.taskPack.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:35
* @route '/flowtrack/task-packs/{taskPack}'
*/
update.put = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:35
* @route '/flowtrack/task-packs/{taskPack}'
*/
const updateForm = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:35
* @route '/flowtrack/task-packs/{taskPack}'
*/
updateForm.put = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const taskPacks = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    items: Object.assign(items, items),
}

export default taskPacks