import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:50
* @route '/flowtrack/task-packs/{taskPack}/items'
*/
export const store = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/task-packs/{taskPack}/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:50
* @route '/flowtrack/task-packs/{taskPack}/items'
*/
store.url = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskPack: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { taskPack: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            taskPack: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        taskPack: typeof args.taskPack === 'object'
        ? args.taskPack.id
        : args.taskPack,
    }

    return store.definition.url
            .replace('{taskPack}', parsedArgs.taskPack.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:50
* @route '/flowtrack/task-packs/{taskPack}/items'
*/
store.post = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:50
* @route '/flowtrack/task-packs/{taskPack}/items'
*/
const storeForm = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:50
* @route '/flowtrack/task-packs/{taskPack}/items'
*/
storeForm.post = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:64
* @route '/flowtrack/task-pack-items/{item}'
*/
export const update = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/flowtrack/task-pack-items/{item}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:64
* @route '/flowtrack/task-pack-items/{item}'
*/
update.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return update.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:64
* @route '/flowtrack/task-pack-items/{item}'
*/
update.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:64
* @route '/flowtrack/task-pack-items/{item}'
*/
const updateForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:64
* @route '/flowtrack/task-pack-items/{item}'
*/
updateForm.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::destroy
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:73
* @route '/flowtrack/task-pack-items/{item}'
*/
export const destroy = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/flowtrack/task-pack-items/{item}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::destroy
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:73
* @route '/flowtrack/task-pack-items/{item}'
*/
destroy.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return destroy.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::destroy
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:73
* @route '/flowtrack/task-pack-items/{item}'
*/
destroy.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::destroy
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:73
* @route '/flowtrack/task-pack-items/{item}'
*/
const destroyForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::destroy
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:73
* @route '/flowtrack/task-pack-items/{item}'
*/
destroyForm.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const items = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default items