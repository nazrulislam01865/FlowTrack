import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import clients from './clients'
import jobs from './jobs'
import tasks from './tasks'
import masterData from './master-data'
import taskPacks from './task-packs'
/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
export const bootstrap = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bootstrap.url(options),
    method: 'get',
})

bootstrap.definition = {
    methods: ["get","head"],
    url: '/flowtrack/template-api/bootstrap',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
bootstrap.url = (options?: RouteQueryOptions) => {
    return bootstrap.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
bootstrap.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bootstrap.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
bootstrap.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: bootstrap.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
const bootstrapForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: bootstrap.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
bootstrapForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: bootstrap.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
bootstrapForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: bootstrap.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

bootstrap.form = bootstrapForm

const templateApi = {
    bootstrap: Object.assign(bootstrap, bootstrap),
    clients: Object.assign(clients, clients),
    jobs: Object.assign(jobs, jobs),
    tasks: Object.assign(tasks, tasks),
    masterData: Object.assign(masterData, masterData),
    taskPacks: Object.assign(taskPacks, taskPacks),
}

export default templateApi