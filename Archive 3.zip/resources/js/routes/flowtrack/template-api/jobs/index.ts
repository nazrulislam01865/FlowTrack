import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::store
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:209
* @route '/flowtrack/template-api/jobs'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/template-api/jobs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::store
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:209
* @route '/flowtrack/template-api/jobs'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::store
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:209
* @route '/flowtrack/template-api/jobs'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::store
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:209
* @route '/flowtrack/template-api/jobs'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::store
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:209
* @route '/flowtrack/template-api/jobs'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::phase
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:271
* @route '/flowtrack/template-api/jobs/{job}/phase'
*/
export const phase = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: phase.url(args, options),
    method: 'patch',
})

phase.definition = {
    methods: ["patch"],
    url: '/flowtrack/template-api/jobs/{job}/phase',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::phase
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:271
* @route '/flowtrack/template-api/jobs/{job}/phase'
*/
phase.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return phase.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::phase
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:271
* @route '/flowtrack/template-api/jobs/{job}/phase'
*/
phase.patch = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: phase.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::phase
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:271
* @route '/flowtrack/template-api/jobs/{job}/phase'
*/
const phaseForm = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: phase.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::phase
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:271
* @route '/flowtrack/template-api/jobs/{job}/phase'
*/
phaseForm.patch = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: phase.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

phase.form = phaseForm

const jobs = {
    store: Object.assign(store, store),
    phase: Object.assign(phase, phase),
}

export default jobs