import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
export const nextCode = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: nextCode.url(options),
    method: 'get',
})

nextCode.definition = {
    methods: ["get","head"],
    url: '/flowtrack/template-api/task-packs/next-code',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
nextCode.url = (options?: RouteQueryOptions) => {
    return nextCode.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
nextCode.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: nextCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
nextCode.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: nextCode.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
const nextCodeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
nextCodeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
nextCodeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextCode.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

nextCode.form = nextCodeForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::store
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:92
* @route '/flowtrack/template-api/task-packs'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/template-api/task-packs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::store
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:92
* @route '/flowtrack/template-api/task-packs'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::store
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:92
* @route '/flowtrack/template-api/task-packs'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::store
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:92
* @route '/flowtrack/template-api/task-packs'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::store
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:92
* @route '/flowtrack/template-api/task-packs'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::update
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:118
* @route '/flowtrack/template-api/task-packs/{taskPack}'
*/
export const update = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/flowtrack/template-api/task-packs/{taskPack}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::update
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:118
* @route '/flowtrack/template-api/task-packs/{taskPack}'
*/
update.url = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskPack: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { taskPack: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            taskPack: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        taskPack: typeof args.taskPack === 'object'
        ? args.taskPack.id
        : args.taskPack,
    }

    return update.definition.url
            .replace('{taskPack}', parsedArgs.taskPack.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::update
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:118
* @route '/flowtrack/template-api/task-packs/{taskPack}'
*/
update.put = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::update
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:118
* @route '/flowtrack/template-api/task-packs/{taskPack}'
*/
const updateForm = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::update
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:118
* @route '/flowtrack/template-api/task-packs/{taskPack}'
*/
updateForm.put = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const taskPacks = {
    nextCode: Object.assign(nextCode, nextCode),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
}

export default taskPacks