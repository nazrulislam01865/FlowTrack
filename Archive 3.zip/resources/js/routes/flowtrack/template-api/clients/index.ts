import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::store
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:186
* @route '/flowtrack/template-api/clients'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/template-api/clients',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::store
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:186
* @route '/flowtrack/template-api/clients'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::store
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:186
* @route '/flowtrack/template-api/clients'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::store
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:186
* @route '/flowtrack/template-api/clients'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::store
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:186
* @route '/flowtrack/template-api/clients'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::update
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:197
* @route '/flowtrack/template-api/clients/{client}'
*/
export const update = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/flowtrack/template-api/clients/{client}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::update
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:197
* @route '/flowtrack/template-api/clients/{client}'
*/
update.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { client: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            client: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        client: typeof args.client === 'object'
        ? args.client.id
        : args.client,
    }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::update
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:197
* @route '/flowtrack/template-api/clients/{client}'
*/
update.put = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::update
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:197
* @route '/flowtrack/template-api/clients/{client}'
*/
const updateForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::update
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:197
* @route '/flowtrack/template-api/clients/{client}'
*/
updateForm.put = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const clients = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
}

export default clients