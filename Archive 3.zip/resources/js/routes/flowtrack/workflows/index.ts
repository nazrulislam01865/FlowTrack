import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import phases from './phases'
/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/flowtrack/workflow-setup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:31
* @route '/flowtrack/workflow-setup'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/workflow-setup',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:31
* @route '/flowtrack/workflow-setup'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:31
* @route '/flowtrack/workflow-setup'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:31
* @route '/flowtrack/workflow-setup'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:31
* @route '/flowtrack/workflow-setup'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::reorder
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:117
* @route '/flowtrack/workflow-setup/{workflow}/reorder'
*/
export const reorder = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorder.url(args, options),
    method: 'patch',
})

reorder.definition = {
    methods: ["patch"],
    url: '/flowtrack/workflow-setup/{workflow}/reorder',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::reorder
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:117
* @route '/flowtrack/workflow-setup/{workflow}/reorder'
*/
reorder.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { workflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            workflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workflow: typeof args.workflow === 'object'
        ? args.workflow.id
        : args.workflow,
    }

    return reorder.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::reorder
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:117
* @route '/flowtrack/workflow-setup/{workflow}/reorder'
*/
reorder.patch = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorder.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::reorder
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:117
* @route '/flowtrack/workflow-setup/{workflow}/reorder'
*/
const reorderForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reorder.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::reorder
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:117
* @route '/flowtrack/workflow-setup/{workflow}/reorder'
*/
reorderForm.patch = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reorder.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

reorder.form = reorderForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::publish
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:137
* @route '/flowtrack/workflow-setup/{workflow}/publish'
*/
export const publish = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publish.url(args, options),
    method: 'patch',
})

publish.definition = {
    methods: ["patch"],
    url: '/flowtrack/workflow-setup/{workflow}/publish',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::publish
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:137
* @route '/flowtrack/workflow-setup/{workflow}/publish'
*/
publish.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { workflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            workflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workflow: typeof args.workflow === 'object'
        ? args.workflow.id
        : args.workflow,
    }

    return publish.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::publish
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:137
* @route '/flowtrack/workflow-setup/{workflow}/publish'
*/
publish.patch = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publish.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::publish
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:137
* @route '/flowtrack/workflow-setup/{workflow}/publish'
*/
const publishForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: publish.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::publish
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:137
* @route '/flowtrack/workflow-setup/{workflow}/publish'
*/
publishForm.patch = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: publish.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

publish.form = publishForm

const workflows = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    phases: Object.assign(phases, phases),
    reorder: Object.assign(reorder, reorder),
    publish: Object.assign(publish, publish),
}

export default workflows