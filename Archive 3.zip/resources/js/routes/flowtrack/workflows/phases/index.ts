import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:61
* @route '/flowtrack/workflow-setup/{workflow}/phases'
*/
export const store = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/workflow-setup/{workflow}/phases',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:61
* @route '/flowtrack/workflow-setup/{workflow}/phases'
*/
store.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { workflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            workflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workflow: typeof args.workflow === 'object'
        ? args.workflow.id
        : args.workflow,
    }

    return store.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:61
* @route '/flowtrack/workflow-setup/{workflow}/phases'
*/
store.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:61
* @route '/flowtrack/workflow-setup/{workflow}/phases'
*/
const storeForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:61
* @route '/flowtrack/workflow-setup/{workflow}/phases'
*/
storeForm.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::update
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:86
* @route '/flowtrack/workflow-phases/{phase}'
*/
export const update = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/flowtrack/workflow-phases/{phase}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::update
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:86
* @route '/flowtrack/workflow-phases/{phase}'
*/
update.url = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { phase: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { phase: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            phase: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        phase: typeof args.phase === 'object'
        ? args.phase.id
        : args.phase,
    }

    return update.definition.url
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::update
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:86
* @route '/flowtrack/workflow-phases/{phase}'
*/
update.put = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::update
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:86
* @route '/flowtrack/workflow-phases/{phase}'
*/
const updateForm = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::update
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:86
* @route '/flowtrack/workflow-phases/{phase}'
*/
updateForm.put = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::destroy
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:108
* @route '/flowtrack/workflow-phases/{phase}'
*/
export const destroy = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/flowtrack/workflow-phases/{phase}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::destroy
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:108
* @route '/flowtrack/workflow-phases/{phase}'
*/
destroy.url = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { phase: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { phase: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            phase: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        phase: typeof args.phase === 'object'
        ? args.phase.id
        : args.phase,
    }

    return destroy.definition.url
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::destroy
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:108
* @route '/flowtrack/workflow-phases/{phase}'
*/
destroy.delete = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::destroy
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:108
* @route '/flowtrack/workflow-phases/{phase}'
*/
const destroyForm = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::destroy
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:108
* @route '/flowtrack/workflow-phases/{phase}'
*/
destroyForm.delete = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const phases = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default phases