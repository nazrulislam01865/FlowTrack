import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import templateApi from './template-api'
import jobs from './jobs'
import clients from './clients'
import board from './board'
import tasks from './tasks'
import documents from './documents'
import notifications from './notifications'
import workflows from './workflows'
import taskPacks from './task-packs'
import masterData from './master-data'
import administration from './administration'
/**
* @see routes/web.php:24
* @route '/flowtrack'
*/
export const prototype = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: prototype.url(options),
    method: 'get',
})

prototype.definition = {
    methods: ["get","head"],
    url: '/flowtrack',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:24
* @route '/flowtrack'
*/
prototype.url = (options?: RouteQueryOptions) => {
    return prototype.definition.url + queryParams(options)
}

/**
* @see routes/web.php:24
* @route '/flowtrack'
*/
prototype.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: prototype.url(options),
    method: 'get',
})

/**
* @see routes/web.php:24
* @route '/flowtrack'
*/
prototype.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: prototype.url(options),
    method: 'head',
})

/**
* @see routes/web.php:24
* @route '/flowtrack'
*/
const prototypeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: prototype.url(options),
    method: 'get',
})

/**
* @see routes/web.php:24
* @route '/flowtrack'
*/
prototypeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: prototype.url(options),
    method: 'get',
})

/**
* @see routes/web.php:24
* @route '/flowtrack'
*/
prototypeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: prototype.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

prototype.form = prototypeForm

/**
* @see routes/web.php:25
* @route '/flowtrack/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/flowtrack/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:25
* @route '/flowtrack/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see routes/web.php:25
* @route '/flowtrack/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see routes/web.php:25
* @route '/flowtrack/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see routes/web.php:25
* @route '/flowtrack/dashboard'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see routes/web.php:25
* @route '/flowtrack/dashboard'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see routes/web.php:25
* @route '/flowtrack/dashboard'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\FlowTrack\GlobalSearchController::__invoke
* @see app/Http/Controllers/FlowTrack/GlobalSearchController.php:17
* @route '/flowtrack/search'
*/
export const search = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

search.definition = {
    methods: ["get","head"],
    url: '/flowtrack/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\GlobalSearchController::__invoke
* @see app/Http/Controllers/FlowTrack/GlobalSearchController.php:17
* @route '/flowtrack/search'
*/
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\GlobalSearchController::__invoke
* @see app/Http/Controllers/FlowTrack/GlobalSearchController.php:17
* @route '/flowtrack/search'
*/
search.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\GlobalSearchController::__invoke
* @see app/Http/Controllers/FlowTrack/GlobalSearchController.php:17
* @route '/flowtrack/search'
*/
search.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\GlobalSearchController::__invoke
* @see app/Http/Controllers/FlowTrack/GlobalSearchController.php:17
* @route '/flowtrack/search'
*/
const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\GlobalSearchController::__invoke
* @see app/Http/Controllers/FlowTrack/GlobalSearchController.php:17
* @route '/flowtrack/search'
*/
searchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\GlobalSearchController::__invoke
* @see app/Http/Controllers/FlowTrack/GlobalSearchController.php:17
* @route '/flowtrack/search'
*/
searchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

search.form = searchForm

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
export const myWork = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myWork.url(options),
    method: 'get',
})

myWork.definition = {
    methods: ["get","head"],
    url: '/flowtrack/my-work',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
myWork.url = (options?: RouteQueryOptions) => {
    return myWork.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
myWork.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: myWork.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
myWork.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: myWork.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
const myWorkForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: myWork.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
myWorkForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: myWork.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
myWorkForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: myWork.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

myWork.form = myWorkForm

/**
* @see \App\Http\Controllers\FlowTrack\ReportController::__invoke
* @see app/Http/Controllers/FlowTrack/ReportController.php:19
* @route '/flowtrack/reports'
*/
export const reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

reports.definition = {
    methods: ["get","head"],
    url: '/flowtrack/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\ReportController::__invoke
* @see app/Http/Controllers/FlowTrack/ReportController.php:19
* @route '/flowtrack/reports'
*/
reports.url = (options?: RouteQueryOptions) => {
    return reports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\ReportController::__invoke
* @see app/Http/Controllers/FlowTrack/ReportController.php:19
* @route '/flowtrack/reports'
*/
reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\ReportController::__invoke
* @see app/Http/Controllers/FlowTrack/ReportController.php:19
* @route '/flowtrack/reports'
*/
reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reports.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\ReportController::__invoke
* @see app/Http/Controllers/FlowTrack/ReportController.php:19
* @route '/flowtrack/reports'
*/
const reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\ReportController::__invoke
* @see app/Http/Controllers/FlowTrack/ReportController.php:19
* @route '/flowtrack/reports'
*/
reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\ReportController::__invoke
* @see app/Http/Controllers/FlowTrack/ReportController.php:19
* @route '/flowtrack/reports'
*/
reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

reports.form = reportsForm

const flowtrack = {
    prototype: Object.assign(prototype, prototype),
    dashboard: Object.assign(dashboard, dashboard),
    templateApi: Object.assign(templateApi, templateApi),
    search: Object.assign(search, search),
    myWork: Object.assign(myWork, myWork),
    jobs: Object.assign(jobs, jobs),
    clients: Object.assign(clients, clients),
    board: Object.assign(board, board),
    tasks: Object.assign(tasks, tasks),
    documents: Object.assign(documents, documents),
    reports: Object.assign(reports, reports),
    notifications: Object.assign(notifications, notifications),
    workflows: Object.assign(workflows, workflows),
    taskPacks: Object.assign(taskPacks, taskPacks),
    masterData: Object.assign(masterData, masterData),
    administration: Object.assign(administration, administration),
}

export default flowtrack