import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::index
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:20
* @route '/flowtrack/master-data'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/flowtrack/master-data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::index
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:20
* @route '/flowtrack/master-data'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::index
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:20
* @route '/flowtrack/master-data'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::index
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:20
* @route '/flowtrack/master-data'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::index
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:20
* @route '/flowtrack/master-data'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::index
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:20
* @route '/flowtrack/master-data'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::index
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:20
* @route '/flowtrack/master-data'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::store
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:35
* @route '/flowtrack/master-data'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/master-data',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::store
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:35
* @route '/flowtrack/master-data'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::store
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:35
* @route '/flowtrack/master-data'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::store
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:35
* @route '/flowtrack/master-data'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::store
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:35
* @route '/flowtrack/master-data'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::update
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:58
* @route '/flowtrack/master-data/{record}'
*/
export const update = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/flowtrack/master-data/{record}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::update
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:58
* @route '/flowtrack/master-data/{record}'
*/
update.url = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { record: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { record: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            record: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        record: typeof args.record === 'object'
        ? args.record.id
        : args.record,
    }

    return update.definition.url
            .replace('{record}', parsedArgs.record.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::update
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:58
* @route '/flowtrack/master-data/{record}'
*/
update.put = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::update
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:58
* @route '/flowtrack/master-data/{record}'
*/
const updateForm = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::update
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:58
* @route '/flowtrack/master-data/{record}'
*/
updateForm.put = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::toggle
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:76
* @route '/flowtrack/master-data/{record}/toggle'
*/
export const toggle = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggle.url(args, options),
    method: 'patch',
})

toggle.definition = {
    methods: ["patch"],
    url: '/flowtrack/master-data/{record}/toggle',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::toggle
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:76
* @route '/flowtrack/master-data/{record}/toggle'
*/
toggle.url = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { record: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { record: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            record: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        record: typeof args.record === 'object'
        ? args.record.id
        : args.record,
    }

    return toggle.definition.url
            .replace('{record}', parsedArgs.record.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::toggle
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:76
* @route '/flowtrack/master-data/{record}/toggle'
*/
toggle.patch = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggle.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::toggle
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:76
* @route '/flowtrack/master-data/{record}/toggle'
*/
const toggleForm = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggle.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\MasterDataController::toggle
* @see app/Http/Controllers/FlowTrack/MasterDataController.php:76
* @route '/flowtrack/master-data/{record}/toggle'
*/
toggleForm.patch = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggle.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

toggle.form = toggleForm

const masterData = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    toggle: Object.assign(toggle, toggle),
}

export default masterData