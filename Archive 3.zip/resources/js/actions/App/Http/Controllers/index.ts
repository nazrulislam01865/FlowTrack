import FlowTrack from './FlowTrack'
import Settings from './Settings'

const Controllers = {
    FlowTrack: Object.assign(FlowTrack, FlowTrack),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers