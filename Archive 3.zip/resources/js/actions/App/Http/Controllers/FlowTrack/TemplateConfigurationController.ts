import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextMasterCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:19
* @route '/flowtrack/template-api/master-data/next-code'
*/
export const nextMasterCode = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: nextMasterCode.url(options),
    method: 'get',
})

nextMasterCode.definition = {
    methods: ["get","head"],
    url: '/flowtrack/template-api/master-data/next-code',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextMasterCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:19
* @route '/flowtrack/template-api/master-data/next-code'
*/
nextMasterCode.url = (options?: RouteQueryOptions) => {
    return nextMasterCode.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextMasterCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:19
* @route '/flowtrack/template-api/master-data/next-code'
*/
nextMasterCode.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: nextMasterCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextMasterCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:19
* @route '/flowtrack/template-api/master-data/next-code'
*/
nextMasterCode.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: nextMasterCode.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextMasterCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:19
* @route '/flowtrack/template-api/master-data/next-code'
*/
const nextMasterCodeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextMasterCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextMasterCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:19
* @route '/flowtrack/template-api/master-data/next-code'
*/
nextMasterCodeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextMasterCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextMasterCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:19
* @route '/flowtrack/template-api/master-data/next-code'
*/
nextMasterCodeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextMasterCode.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

nextMasterCode.form = nextMasterCodeForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::storeMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:28
* @route '/flowtrack/template-api/master-data'
*/
export const storeMaster = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMaster.url(options),
    method: 'post',
})

storeMaster.definition = {
    methods: ["post"],
    url: '/flowtrack/template-api/master-data',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::storeMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:28
* @route '/flowtrack/template-api/master-data'
*/
storeMaster.url = (options?: RouteQueryOptions) => {
    return storeMaster.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::storeMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:28
* @route '/flowtrack/template-api/master-data'
*/
storeMaster.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMaster.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::storeMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:28
* @route '/flowtrack/template-api/master-data'
*/
const storeMasterForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeMaster.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::storeMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:28
* @route '/flowtrack/template-api/master-data'
*/
storeMasterForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeMaster.url(options),
    method: 'post',
})

storeMaster.form = storeMasterForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::updateMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:57
* @route '/flowtrack/template-api/master-data/{record}'
*/
export const updateMaster = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateMaster.url(args, options),
    method: 'put',
})

updateMaster.definition = {
    methods: ["put"],
    url: '/flowtrack/template-api/master-data/{record}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::updateMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:57
* @route '/flowtrack/template-api/master-data/{record}'
*/
updateMaster.url = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { record: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { record: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            record: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        record: typeof args.record === 'object'
        ? args.record.id
        : args.record,
    }

    return updateMaster.definition.url
            .replace('{record}', parsedArgs.record.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::updateMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:57
* @route '/flowtrack/template-api/master-data/{record}'
*/
updateMaster.put = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateMaster.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::updateMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:57
* @route '/flowtrack/template-api/master-data/{record}'
*/
const updateMasterForm = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateMaster.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::updateMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:57
* @route '/flowtrack/template-api/master-data/{record}'
*/
updateMasterForm.put = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateMaster.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateMaster.form = updateMasterForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::toggleMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:76
* @route '/flowtrack/template-api/master-data/{record}/toggle'
*/
export const toggleMaster = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleMaster.url(args, options),
    method: 'patch',
})

toggleMaster.definition = {
    methods: ["patch"],
    url: '/flowtrack/template-api/master-data/{record}/toggle',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::toggleMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:76
* @route '/flowtrack/template-api/master-data/{record}/toggle'
*/
toggleMaster.url = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { record: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { record: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            record: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        record: typeof args.record === 'object'
        ? args.record.id
        : args.record,
    }

    return toggleMaster.definition.url
            .replace('{record}', parsedArgs.record.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::toggleMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:76
* @route '/flowtrack/template-api/master-data/{record}/toggle'
*/
toggleMaster.patch = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleMaster.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::toggleMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:76
* @route '/flowtrack/template-api/master-data/{record}/toggle'
*/
const toggleMasterForm = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleMaster.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::toggleMaster
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:76
* @route '/flowtrack/template-api/master-data/{record}/toggle'
*/
toggleMasterForm.patch = (args: { record: number | { id: number } } | [record: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleMaster.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

toggleMaster.form = toggleMasterForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextTaskPackCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
export const nextTaskPackCode = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: nextTaskPackCode.url(options),
    method: 'get',
})

nextTaskPackCode.definition = {
    methods: ["get","head"],
    url: '/flowtrack/template-api/task-packs/next-code',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextTaskPackCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
nextTaskPackCode.url = (options?: RouteQueryOptions) => {
    return nextTaskPackCode.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextTaskPackCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
nextTaskPackCode.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: nextTaskPackCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextTaskPackCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
nextTaskPackCode.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: nextTaskPackCode.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextTaskPackCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
const nextTaskPackCodeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextTaskPackCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextTaskPackCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
nextTaskPackCodeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextTaskPackCode.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::nextTaskPackCode
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:85
* @route '/flowtrack/template-api/task-packs/next-code'
*/
nextTaskPackCodeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: nextTaskPackCode.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

nextTaskPackCode.form = nextTaskPackCodeForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::storeTaskPack
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:92
* @route '/flowtrack/template-api/task-packs'
*/
export const storeTaskPack = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTaskPack.url(options),
    method: 'post',
})

storeTaskPack.definition = {
    methods: ["post"],
    url: '/flowtrack/template-api/task-packs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::storeTaskPack
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:92
* @route '/flowtrack/template-api/task-packs'
*/
storeTaskPack.url = (options?: RouteQueryOptions) => {
    return storeTaskPack.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::storeTaskPack
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:92
* @route '/flowtrack/template-api/task-packs'
*/
storeTaskPack.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTaskPack.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::storeTaskPack
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:92
* @route '/flowtrack/template-api/task-packs'
*/
const storeTaskPackForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeTaskPack.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::storeTaskPack
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:92
* @route '/flowtrack/template-api/task-packs'
*/
storeTaskPackForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeTaskPack.url(options),
    method: 'post',
})

storeTaskPack.form = storeTaskPackForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::updateTaskPack
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:118
* @route '/flowtrack/template-api/task-packs/{taskPack}'
*/
export const updateTaskPack = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTaskPack.url(args, options),
    method: 'put',
})

updateTaskPack.definition = {
    methods: ["put"],
    url: '/flowtrack/template-api/task-packs/{taskPack}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::updateTaskPack
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:118
* @route '/flowtrack/template-api/task-packs/{taskPack}'
*/
updateTaskPack.url = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskPack: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { taskPack: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            taskPack: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        taskPack: typeof args.taskPack === 'object'
        ? args.taskPack.id
        : args.taskPack,
    }

    return updateTaskPack.definition.url
            .replace('{taskPack}', parsedArgs.taskPack.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::updateTaskPack
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:118
* @route '/flowtrack/template-api/task-packs/{taskPack}'
*/
updateTaskPack.put = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTaskPack.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::updateTaskPack
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:118
* @route '/flowtrack/template-api/task-packs/{taskPack}'
*/
const updateTaskPackForm = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateTaskPack.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateConfigurationController::updateTaskPack
* @see app/Http/Controllers/FlowTrack/TemplateConfigurationController.php:118
* @route '/flowtrack/template-api/task-packs/{taskPack}'
*/
updateTaskPackForm.put = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateTaskPack.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateTaskPack.form = updateTaskPackForm

const TemplateConfigurationController = { nextMasterCode, storeMaster, updateMaster, toggleMaster, nextTaskPackCode, storeTaskPack, updateTaskPack }

export default TemplateConfigurationController