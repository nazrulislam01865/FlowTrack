import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
export const bootstrap = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bootstrap.url(options),
    method: 'get',
})

bootstrap.definition = {
    methods: ["get","head"],
    url: '/flowtrack/template-api/bootstrap',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
bootstrap.url = (options?: RouteQueryOptions) => {
    return bootstrap.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
bootstrap.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bootstrap.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
bootstrap.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: bootstrap.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
const bootstrapForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: bootstrap.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
bootstrapForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: bootstrap.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::bootstrap
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:39
* @route '/flowtrack/template-api/bootstrap'
*/
bootstrapForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: bootstrap.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

bootstrap.form = bootstrapForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::storeClient
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:186
* @route '/flowtrack/template-api/clients'
*/
export const storeClient = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeClient.url(options),
    method: 'post',
})

storeClient.definition = {
    methods: ["post"],
    url: '/flowtrack/template-api/clients',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::storeClient
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:186
* @route '/flowtrack/template-api/clients'
*/
storeClient.url = (options?: RouteQueryOptions) => {
    return storeClient.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::storeClient
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:186
* @route '/flowtrack/template-api/clients'
*/
storeClient.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeClient.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::storeClient
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:186
* @route '/flowtrack/template-api/clients'
*/
const storeClientForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeClient.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::storeClient
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:186
* @route '/flowtrack/template-api/clients'
*/
storeClientForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeClient.url(options),
    method: 'post',
})

storeClient.form = storeClientForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::updateClient
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:197
* @route '/flowtrack/template-api/clients/{client}'
*/
export const updateClient = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateClient.url(args, options),
    method: 'put',
})

updateClient.definition = {
    methods: ["put"],
    url: '/flowtrack/template-api/clients/{client}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::updateClient
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:197
* @route '/flowtrack/template-api/clients/{client}'
*/
updateClient.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { client: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            client: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        client: typeof args.client === 'object'
        ? args.client.id
        : args.client,
    }

    return updateClient.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::updateClient
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:197
* @route '/flowtrack/template-api/clients/{client}'
*/
updateClient.put = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateClient.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::updateClient
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:197
* @route '/flowtrack/template-api/clients/{client}'
*/
const updateClientForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateClient.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::updateClient
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:197
* @route '/flowtrack/template-api/clients/{client}'
*/
updateClientForm.put = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateClient.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateClient.form = updateClientForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::storeJob
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:209
* @route '/flowtrack/template-api/jobs'
*/
export const storeJob = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeJob.url(options),
    method: 'post',
})

storeJob.definition = {
    methods: ["post"],
    url: '/flowtrack/template-api/jobs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::storeJob
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:209
* @route '/flowtrack/template-api/jobs'
*/
storeJob.url = (options?: RouteQueryOptions) => {
    return storeJob.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::storeJob
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:209
* @route '/flowtrack/template-api/jobs'
*/
storeJob.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeJob.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::storeJob
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:209
* @route '/flowtrack/template-api/jobs'
*/
const storeJobForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeJob.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::storeJob
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:209
* @route '/flowtrack/template-api/jobs'
*/
storeJobForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeJob.url(options),
    method: 'post',
})

storeJob.form = storeJobForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::updateTask
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:246
* @route '/flowtrack/template-api/tasks/{task}'
*/
export const updateTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTask.url(args, options),
    method: 'put',
})

updateTask.definition = {
    methods: ["put"],
    url: '/flowtrack/template-api/tasks/{task}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::updateTask
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:246
* @route '/flowtrack/template-api/tasks/{task}'
*/
updateTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { task: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            task: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        task: typeof args.task === 'object'
        ? args.task.id
        : args.task,
    }

    return updateTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::updateTask
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:246
* @route '/flowtrack/template-api/tasks/{task}'
*/
updateTask.put = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateTask.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::updateTask
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:246
* @route '/flowtrack/template-api/tasks/{task}'
*/
const updateTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateTask.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::updateTask
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:246
* @route '/flowtrack/template-api/tasks/{task}'
*/
updateTaskForm.put = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateTask.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateTask.form = updateTaskForm

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::moveJob
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:271
* @route '/flowtrack/template-api/jobs/{job}/phase'
*/
export const moveJob = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: moveJob.url(args, options),
    method: 'patch',
})

moveJob.definition = {
    methods: ["patch"],
    url: '/flowtrack/template-api/jobs/{job}/phase',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::moveJob
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:271
* @route '/flowtrack/template-api/jobs/{job}/phase'
*/
moveJob.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return moveJob.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::moveJob
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:271
* @route '/flowtrack/template-api/jobs/{job}/phase'
*/
moveJob.patch = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: moveJob.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::moveJob
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:271
* @route '/flowtrack/template-api/jobs/{job}/phase'
*/
const moveJobForm = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: moveJob.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TemplateApiController::moveJob
* @see app/Http/Controllers/FlowTrack/TemplateApiController.php:271
* @route '/flowtrack/template-api/jobs/{job}/phase'
*/
moveJobForm.patch = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: moveJob.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

moveJob.form = moveJobForm

const TemplateApiController = { bootstrap, storeClient, updateClient, storeJob, updateTask, moveJob }

export default TemplateApiController