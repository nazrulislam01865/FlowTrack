import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/flowtrack/administration',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::index
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:24
* @route '/flowtrack/administration'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::storeRole
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:39
* @route '/flowtrack/administration/roles'
*/
export const storeRole = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRole.url(options),
    method: 'post',
})

storeRole.definition = {
    methods: ["post"],
    url: '/flowtrack/administration/roles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::storeRole
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:39
* @route '/flowtrack/administration/roles'
*/
storeRole.url = (options?: RouteQueryOptions) => {
    return storeRole.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::storeRole
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:39
* @route '/flowtrack/administration/roles'
*/
storeRole.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeRole.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::storeRole
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:39
* @route '/flowtrack/administration/roles'
*/
const storeRoleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeRole.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::storeRole
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:39
* @route '/flowtrack/administration/roles'
*/
storeRoleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeRole.url(options),
    method: 'post',
})

storeRole.form = storeRoleForm

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::updateRole
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:62
* @route '/flowtrack/administration/roles/{role}'
*/
export const updateRole = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateRole.url(args, options),
    method: 'put',
})

updateRole.definition = {
    methods: ["put"],
    url: '/flowtrack/administration/roles/{role}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::updateRole
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:62
* @route '/flowtrack/administration/roles/{role}'
*/
updateRole.url = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { role: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { role: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            role: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        role: typeof args.role === 'object'
        ? args.role.id
        : args.role,
    }

    return updateRole.definition.url
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::updateRole
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:62
* @route '/flowtrack/administration/roles/{role}'
*/
updateRole.put = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateRole.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::updateRole
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:62
* @route '/flowtrack/administration/roles/{role}'
*/
const updateRoleForm = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateRole.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::updateRole
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:62
* @route '/flowtrack/administration/roles/{role}'
*/
updateRoleForm.put = (args: { role: number | { id: number } } | [role: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateRole.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateRole.form = updateRoleForm

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::storeMember
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:87
* @route '/flowtrack/administration/members'
*/
export const storeMember = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMember.url(options),
    method: 'post',
})

storeMember.definition = {
    methods: ["post"],
    url: '/flowtrack/administration/members',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::storeMember
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:87
* @route '/flowtrack/administration/members'
*/
storeMember.url = (options?: RouteQueryOptions) => {
    return storeMember.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::storeMember
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:87
* @route '/flowtrack/administration/members'
*/
storeMember.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMember.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::storeMember
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:87
* @route '/flowtrack/administration/members'
*/
const storeMemberForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeMember.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::storeMember
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:87
* @route '/flowtrack/administration/members'
*/
storeMemberForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeMember.url(options),
    method: 'post',
})

storeMember.form = storeMemberForm

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::updateMember
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:124
* @route '/flowtrack/administration/members/{membership}'
*/
export const updateMember = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateMember.url(args, options),
    method: 'put',
})

updateMember.definition = {
    methods: ["put"],
    url: '/flowtrack/administration/members/{membership}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::updateMember
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:124
* @route '/flowtrack/administration/members/{membership}'
*/
updateMember.url = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { membership: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { membership: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            membership: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        membership: typeof args.membership === 'object'
        ? args.membership.id
        : args.membership,
    }

    return updateMember.definition.url
            .replace('{membership}', parsedArgs.membership.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::updateMember
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:124
* @route '/flowtrack/administration/members/{membership}'
*/
updateMember.put = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateMember.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::updateMember
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:124
* @route '/flowtrack/administration/members/{membership}'
*/
const updateMemberForm = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateMember.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\AdministrationController::updateMember
* @see app/Http/Controllers/FlowTrack/AdministrationController.php:124
* @route '/flowtrack/administration/members/{membership}'
*/
updateMemberForm.put = (args: { membership: number | { id: number } } | [membership: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateMember.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateMember.form = updateMemberForm

const AdministrationController = { index, storeRole, updateRole, storeMember, updateMember }

export default AdministrationController