import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/flowtrack/documents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::index
* @see app/Http/Controllers/FlowTrack/DocumentController.php:24
* @route '/flowtrack/documents'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::store
* @see app/Http/Controllers/FlowTrack/DocumentController.php:62
* @route '/flowtrack/documents'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/documents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::store
* @see app/Http/Controllers/FlowTrack/DocumentController.php:62
* @route '/flowtrack/documents'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::store
* @see app/Http/Controllers/FlowTrack/DocumentController.php:62
* @route '/flowtrack/documents'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::store
* @see app/Http/Controllers/FlowTrack/DocumentController.php:62
* @route '/flowtrack/documents'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::store
* @see app/Http/Controllers/FlowTrack/DocumentController.php:62
* @route '/flowtrack/documents'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
export const download = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/flowtrack/documents/versions/{version}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
download.url = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { version: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { version: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            version: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        version: typeof args.version === 'object'
        ? args.version.id
        : args.version,
    }

    return download.definition.url
            .replace('{version}', parsedArgs.version.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
download.get = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
download.head = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
const downloadForm = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
downloadForm.get = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\DocumentController::download
* @see app/Http/Controllers/FlowTrack/DocumentController.php:53
* @route '/flowtrack/documents/versions/{version}/download'
*/
downloadForm.head = (args: { version: number | { id: number } } | [version: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

download.form = downloadForm

const DocumentController = { index, store, download }

export default DocumentController