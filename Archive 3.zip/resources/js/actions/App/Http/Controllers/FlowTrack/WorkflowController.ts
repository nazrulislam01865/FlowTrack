import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/flowtrack/workflow-setup',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::index
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:20
* @route '/flowtrack/workflow-setup'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:31
* @route '/flowtrack/workflow-setup'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/workflow-setup',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:31
* @route '/flowtrack/workflow-setup'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:31
* @route '/flowtrack/workflow-setup'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:31
* @route '/flowtrack/workflow-setup'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::store
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:31
* @route '/flowtrack/workflow-setup'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::storePhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:61
* @route '/flowtrack/workflow-setup/{workflow}/phases'
*/
export const storePhase = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePhase.url(args, options),
    method: 'post',
})

storePhase.definition = {
    methods: ["post"],
    url: '/flowtrack/workflow-setup/{workflow}/phases',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::storePhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:61
* @route '/flowtrack/workflow-setup/{workflow}/phases'
*/
storePhase.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { workflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            workflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workflow: typeof args.workflow === 'object'
        ? args.workflow.id
        : args.workflow,
    }

    return storePhase.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::storePhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:61
* @route '/flowtrack/workflow-setup/{workflow}/phases'
*/
storePhase.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storePhase.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::storePhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:61
* @route '/flowtrack/workflow-setup/{workflow}/phases'
*/
const storePhaseForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storePhase.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::storePhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:61
* @route '/flowtrack/workflow-setup/{workflow}/phases'
*/
storePhaseForm.post = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storePhase.url(args, options),
    method: 'post',
})

storePhase.form = storePhaseForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::updatePhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:86
* @route '/flowtrack/workflow-phases/{phase}'
*/
export const updatePhase = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePhase.url(args, options),
    method: 'put',
})

updatePhase.definition = {
    methods: ["put"],
    url: '/flowtrack/workflow-phases/{phase}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::updatePhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:86
* @route '/flowtrack/workflow-phases/{phase}'
*/
updatePhase.url = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { phase: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { phase: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            phase: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        phase: typeof args.phase === 'object'
        ? args.phase.id
        : args.phase,
    }

    return updatePhase.definition.url
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::updatePhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:86
* @route '/flowtrack/workflow-phases/{phase}'
*/
updatePhase.put = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePhase.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::updatePhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:86
* @route '/flowtrack/workflow-phases/{phase}'
*/
const updatePhaseForm = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updatePhase.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::updatePhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:86
* @route '/flowtrack/workflow-phases/{phase}'
*/
updatePhaseForm.put = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updatePhase.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updatePhase.form = updatePhaseForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::destroyPhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:108
* @route '/flowtrack/workflow-phases/{phase}'
*/
export const destroyPhase = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPhase.url(args, options),
    method: 'delete',
})

destroyPhase.definition = {
    methods: ["delete"],
    url: '/flowtrack/workflow-phases/{phase}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::destroyPhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:108
* @route '/flowtrack/workflow-phases/{phase}'
*/
destroyPhase.url = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { phase: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { phase: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            phase: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        phase: typeof args.phase === 'object'
        ? args.phase.id
        : args.phase,
    }

    return destroyPhase.definition.url
            .replace('{phase}', parsedArgs.phase.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::destroyPhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:108
* @route '/flowtrack/workflow-phases/{phase}'
*/
destroyPhase.delete = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyPhase.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::destroyPhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:108
* @route '/flowtrack/workflow-phases/{phase}'
*/
const destroyPhaseForm = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyPhase.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::destroyPhase
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:108
* @route '/flowtrack/workflow-phases/{phase}'
*/
destroyPhaseForm.delete = (args: { phase: number | { id: number } } | [phase: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyPhase.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyPhase.form = destroyPhaseForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::reorder
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:117
* @route '/flowtrack/workflow-setup/{workflow}/reorder'
*/
export const reorder = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorder.url(args, options),
    method: 'patch',
})

reorder.definition = {
    methods: ["patch"],
    url: '/flowtrack/workflow-setup/{workflow}/reorder',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::reorder
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:117
* @route '/flowtrack/workflow-setup/{workflow}/reorder'
*/
reorder.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { workflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            workflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workflow: typeof args.workflow === 'object'
        ? args.workflow.id
        : args.workflow,
    }

    return reorder.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::reorder
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:117
* @route '/flowtrack/workflow-setup/{workflow}/reorder'
*/
reorder.patch = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reorder.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::reorder
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:117
* @route '/flowtrack/workflow-setup/{workflow}/reorder'
*/
const reorderForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reorder.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::reorder
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:117
* @route '/flowtrack/workflow-setup/{workflow}/reorder'
*/
reorderForm.patch = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: reorder.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

reorder.form = reorderForm

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::publish
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:137
* @route '/flowtrack/workflow-setup/{workflow}/publish'
*/
export const publish = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publish.url(args, options),
    method: 'patch',
})

publish.definition = {
    methods: ["patch"],
    url: '/flowtrack/workflow-setup/{workflow}/publish',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::publish
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:137
* @route '/flowtrack/workflow-setup/{workflow}/publish'
*/
publish.url = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { workflow: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            workflow: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workflow: typeof args.workflow === 'object'
        ? args.workflow.id
        : args.workflow,
    }

    return publish.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::publish
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:137
* @route '/flowtrack/workflow-setup/{workflow}/publish'
*/
publish.patch = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publish.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::publish
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:137
* @route '/flowtrack/workflow-setup/{workflow}/publish'
*/
const publishForm = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: publish.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\WorkflowController::publish
* @see app/Http/Controllers/FlowTrack/WorkflowController.php:137
* @route '/flowtrack/workflow-setup/{workflow}/publish'
*/
publishForm.patch = (args: { workflow: number | { id: number } } | [workflow: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: publish.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

publish.form = publishForm

const WorkflowController = { index, store, storePhase, updatePhase, destroyPhase, reorder, publish }

export default WorkflowController