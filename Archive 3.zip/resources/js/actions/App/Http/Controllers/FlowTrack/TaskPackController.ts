import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:16
* @route '/flowtrack/task-packs'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/flowtrack/task-packs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:16
* @route '/flowtrack/task-packs'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:16
* @route '/flowtrack/task-packs'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:16
* @route '/flowtrack/task-packs'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::store
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:16
* @route '/flowtrack/task-packs'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:35
* @route '/flowtrack/task-packs/{taskPack}'
*/
export const update = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/flowtrack/task-packs/{taskPack}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:35
* @route '/flowtrack/task-packs/{taskPack}'
*/
update.url = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskPack: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { taskPack: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            taskPack: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        taskPack: typeof args.taskPack === 'object'
        ? args.taskPack.id
        : args.taskPack,
    }

    return update.definition.url
            .replace('{taskPack}', parsedArgs.taskPack.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:35
* @route '/flowtrack/task-packs/{taskPack}'
*/
update.put = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:35
* @route '/flowtrack/task-packs/{taskPack}'
*/
const updateForm = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::update
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:35
* @route '/flowtrack/task-packs/{taskPack}'
*/
updateForm.put = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::storeItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:50
* @route '/flowtrack/task-packs/{taskPack}/items'
*/
export const storeItem = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeItem.url(args, options),
    method: 'post',
})

storeItem.definition = {
    methods: ["post"],
    url: '/flowtrack/task-packs/{taskPack}/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::storeItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:50
* @route '/flowtrack/task-packs/{taskPack}/items'
*/
storeItem.url = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { taskPack: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { taskPack: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            taskPack: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        taskPack: typeof args.taskPack === 'object'
        ? args.taskPack.id
        : args.taskPack,
    }

    return storeItem.definition.url
            .replace('{taskPack}', parsedArgs.taskPack.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::storeItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:50
* @route '/flowtrack/task-packs/{taskPack}/items'
*/
storeItem.post = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeItem.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::storeItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:50
* @route '/flowtrack/task-packs/{taskPack}/items'
*/
const storeItemForm = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeItem.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::storeItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:50
* @route '/flowtrack/task-packs/{taskPack}/items'
*/
storeItemForm.post = (args: { taskPack: number | { id: number } } | [taskPack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeItem.url(args, options),
    method: 'post',
})

storeItem.form = storeItemForm

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::updateItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:64
* @route '/flowtrack/task-pack-items/{item}'
*/
export const updateItem = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItem.url(args, options),
    method: 'put',
})

updateItem.definition = {
    methods: ["put"],
    url: '/flowtrack/task-pack-items/{item}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::updateItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:64
* @route '/flowtrack/task-pack-items/{item}'
*/
updateItem.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return updateItem.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::updateItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:64
* @route '/flowtrack/task-pack-items/{item}'
*/
updateItem.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateItem.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::updateItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:64
* @route '/flowtrack/task-pack-items/{item}'
*/
const updateItemForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::updateItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:64
* @route '/flowtrack/task-pack-items/{item}'
*/
updateItemForm.put = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateItem.form = updateItemForm

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::destroyItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:73
* @route '/flowtrack/task-pack-items/{item}'
*/
export const destroyItem = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyItem.url(args, options),
    method: 'delete',
})

destroyItem.definition = {
    methods: ["delete"],
    url: '/flowtrack/task-pack-items/{item}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::destroyItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:73
* @route '/flowtrack/task-pack-items/{item}'
*/
destroyItem.url = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { item: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            item: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        item: typeof args.item === 'object'
        ? args.item.id
        : args.item,
    }

    return destroyItem.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::destroyItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:73
* @route '/flowtrack/task-pack-items/{item}'
*/
destroyItem.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyItem.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::destroyItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:73
* @route '/flowtrack/task-pack-items/{item}'
*/
const destroyItemForm = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\TaskPackController::destroyItem
* @see app/Http/Controllers/FlowTrack/TaskPackController.php:73
* @route '/flowtrack/task-pack-items/{item}'
*/
destroyItemForm.delete = (args: { item: number | { id: number } } | [item: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyItem.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyItem.form = destroyItemForm

const TaskPackController = { store, update, storeItem, updateItem, destroyItem }

export default TaskPackController