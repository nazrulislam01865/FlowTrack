import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::index
* @see app/Http/Controllers/FlowTrack/NotificationController.php:14
* @route '/flowtrack/notifications'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/flowtrack/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::index
* @see app/Http/Controllers/FlowTrack/NotificationController.php:14
* @route '/flowtrack/notifications'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::index
* @see app/Http/Controllers/FlowTrack/NotificationController.php:14
* @route '/flowtrack/notifications'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::index
* @see app/Http/Controllers/FlowTrack/NotificationController.php:14
* @route '/flowtrack/notifications'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::index
* @see app/Http/Controllers/FlowTrack/NotificationController.php:14
* @route '/flowtrack/notifications'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::index
* @see app/Http/Controllers/FlowTrack/NotificationController.php:14
* @route '/flowtrack/notifications'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::index
* @see app/Http/Controllers/FlowTrack/NotificationController.php:14
* @route '/flowtrack/notifications'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::readAll
* @see app/Http/Controllers/FlowTrack/NotificationController.php:29
* @route '/flowtrack/notifications/read-all'
*/
export const readAll = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: readAll.url(options),
    method: 'patch',
})

readAll.definition = {
    methods: ["patch"],
    url: '/flowtrack/notifications/read-all',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::readAll
* @see app/Http/Controllers/FlowTrack/NotificationController.php:29
* @route '/flowtrack/notifications/read-all'
*/
readAll.url = (options?: RouteQueryOptions) => {
    return readAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::readAll
* @see app/Http/Controllers/FlowTrack/NotificationController.php:29
* @route '/flowtrack/notifications/read-all'
*/
readAll.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: readAll.url(options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::readAll
* @see app/Http/Controllers/FlowTrack/NotificationController.php:29
* @route '/flowtrack/notifications/read-all'
*/
const readAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: readAll.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::readAll
* @see app/Http/Controllers/FlowTrack/NotificationController.php:29
* @route '/flowtrack/notifications/read-all'
*/
readAllForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: readAll.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

readAll.form = readAllForm

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::read
* @see app/Http/Controllers/FlowTrack/NotificationController.php:21
* @route '/flowtrack/notifications/{notification}/read'
*/
export const read = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: read.url(args, options),
    method: 'patch',
})

read.definition = {
    methods: ["patch"],
    url: '/flowtrack/notifications/{notification}/read',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::read
* @see app/Http/Controllers/FlowTrack/NotificationController.php:21
* @route '/flowtrack/notifications/{notification}/read'
*/
read.url = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { notification: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            notification: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        notification: typeof args.notification === 'object'
        ? args.notification.id
        : args.notification,
    }

    return read.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::read
* @see app/Http/Controllers/FlowTrack/NotificationController.php:21
* @route '/flowtrack/notifications/{notification}/read'
*/
read.patch = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: read.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::read
* @see app/Http/Controllers/FlowTrack/NotificationController.php:21
* @route '/flowtrack/notifications/{notification}/read'
*/
const readForm = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: read.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\NotificationController::read
* @see app/Http/Controllers/FlowTrack/NotificationController.php:21
* @route '/flowtrack/notifications/{notification}/read'
*/
readForm.patch = (args: { notification: string | { id: string } } | [notification: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: read.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

read.form = readForm

const NotificationController = { index, readAll, read }

export default NotificationController