import TemplateApiController from './TemplateApiController'
import TemplateConfigurationController from './TemplateConfigurationController'
import GlobalSearchController from './GlobalSearchController'
import MyWorkController from './MyWorkController'
import JobController from './JobController'
import ClientController from './ClientController'
import BoardController from './BoardController'
import TaskController from './TaskController'
import DocumentController from './DocumentController'
import ReportController from './ReportController'
import NotificationController from './NotificationController'
import WorkflowController from './WorkflowController'
import TaskPackController from './TaskPackController'
import MasterDataController from './MasterDataController'
import AdministrationController from './AdministrationController'

const FlowTrack = {
    TemplateApiController: Object.assign(TemplateApiController, TemplateApiController),
    TemplateConfigurationController: Object.assign(TemplateConfigurationController, TemplateConfigurationController),
    GlobalSearchController: Object.assign(GlobalSearchController, GlobalSearchController),
    MyWorkController: Object.assign(MyWorkController, MyWorkController),
    JobController: Object.assign(JobController, JobController),
    ClientController: Object.assign(ClientController, ClientController),
    BoardController: Object.assign(BoardController, BoardController),
    TaskController: Object.assign(TaskController, TaskController),
    DocumentController: Object.assign(DocumentController, DocumentController),
    ReportController: Object.assign(ReportController, ReportController),
    NotificationController: Object.assign(NotificationController, NotificationController),
    WorkflowController: Object.assign(WorkflowController, WorkflowController),
    TaskPackController: Object.assign(TaskPackController, TaskPackController),
    MasterDataController: Object.assign(MasterDataController, MasterDataController),
    AdministrationController: Object.assign(AdministrationController, AdministrationController),
}

export default FlowTrack