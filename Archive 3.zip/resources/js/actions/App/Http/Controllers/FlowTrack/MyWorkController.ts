import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
const MyWorkController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: MyWorkController.url(options),
    method: 'get',
})

MyWorkController.definition = {
    methods: ["get","head"],
    url: '/flowtrack/my-work',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
MyWorkController.url = (options?: RouteQueryOptions) => {
    return MyWorkController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
MyWorkController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: MyWorkController.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
MyWorkController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: MyWorkController.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
const MyWorkControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: MyWorkController.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
MyWorkControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: MyWorkController.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\MyWorkController::__invoke
* @see app/Http/Controllers/FlowTrack/MyWorkController.php:14
* @route '/flowtrack/my-work'
*/
MyWorkControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: MyWorkController.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

MyWorkController.form = MyWorkControllerForm

export default MyWorkController