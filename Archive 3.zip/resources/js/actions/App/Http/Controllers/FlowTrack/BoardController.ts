import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/flowtrack/board',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::index
* @see app/Http/Controllers/FlowTrack/BoardController.php:27
* @route '/flowtrack/board'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::moveJob
* @see app/Http/Controllers/FlowTrack/BoardController.php:36
* @route '/flowtrack/board/jobs/{job}/phase'
*/
export const moveJob = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: moveJob.url(args, options),
    method: 'patch',
})

moveJob.definition = {
    methods: ["patch"],
    url: '/flowtrack/board/jobs/{job}/phase',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::moveJob
* @see app/Http/Controllers/FlowTrack/BoardController.php:36
* @route '/flowtrack/board/jobs/{job}/phase'
*/
moveJob.url = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { job: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { job: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            job: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object'
        ? args.job.id
        : args.job,
    }

    return moveJob.definition.url
            .replace('{job}', parsedArgs.job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::moveJob
* @see app/Http/Controllers/FlowTrack/BoardController.php:36
* @route '/flowtrack/board/jobs/{job}/phase'
*/
moveJob.patch = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: moveJob.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::moveJob
* @see app/Http/Controllers/FlowTrack/BoardController.php:36
* @route '/flowtrack/board/jobs/{job}/phase'
*/
const moveJobForm = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: moveJob.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::moveJob
* @see app/Http/Controllers/FlowTrack/BoardController.php:36
* @route '/flowtrack/board/jobs/{job}/phase'
*/
moveJobForm.patch = (args: { job: number | { id: number } } | [job: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: moveJob.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

moveJob.form = moveJobForm

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::moveTask
* @see app/Http/Controllers/FlowTrack/BoardController.php:50
* @route '/flowtrack/board/tasks/{task}/status'
*/
export const moveTask = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: moveTask.url(args, options),
    method: 'patch',
})

moveTask.definition = {
    methods: ["patch"],
    url: '/flowtrack/board/tasks/{task}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::moveTask
* @see app/Http/Controllers/FlowTrack/BoardController.php:50
* @route '/flowtrack/board/tasks/{task}/status'
*/
moveTask.url = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { task: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { task: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            task: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        task: typeof args.task === 'object'
        ? args.task.id
        : args.task,
    }

    return moveTask.definition.url
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::moveTask
* @see app/Http/Controllers/FlowTrack/BoardController.php:50
* @route '/flowtrack/board/tasks/{task}/status'
*/
moveTask.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: moveTask.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::moveTask
* @see app/Http/Controllers/FlowTrack/BoardController.php:50
* @route '/flowtrack/board/tasks/{task}/status'
*/
const moveTaskForm = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: moveTask.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FlowTrack\BoardController::moveTask
* @see app/Http/Controllers/FlowTrack/BoardController.php:50
* @route '/flowtrack/board/tasks/{task}/status'
*/
moveTaskForm.patch = (args: { task: number | { id: number } } | [task: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: moveTask.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

moveTask.form = moveTaskForm

const BoardController = { index, moveJob, moveTask }

export default BoardController