import { applyUrlDefaults, queryParams, type RouteDefinition, type RouteFormDefinition, type RouteQueryOptions } from './../../../../wayfinder'

/**
* @see \App\Http\Controllers\FlowTrack\JobController::destroyPhase
* @route '/flowtrack/jobs/{job}/phases/{phase}'
*/
export const destroy = (
    args: { job: number | { id: number }; phase: number | { id: number } } | [job: number | { id: number }, phase: number | { id: number }],
    options?: RouteQueryOptions,
): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ['delete'],
    url: '/flowtrack/jobs/{job}/phases/{phase}',
} satisfies RouteDefinition<['delete']>

destroy.url = (
    args: { job: number | { id: number }; phase: number | { id: number } } | [job: number | { id: number }, phase: number | { id: number }],
    options?: RouteQueryOptions,
) => {
    if (Array.isArray(args)) {
        args = { job: args[0], phase: args[1] }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        job: typeof args.job === 'object' ? args.job.id : args.job,
        phase: typeof args.phase === 'object' ? args.phase.id : args.phase,
    }

    return destroy.definition.url
        .replace('{job}', parsedArgs.job.toString())
        .replace('{phase}', parsedArgs.phase.toString())
        .replace(/\/+$/, '') + queryParams(options)
}

destroy.delete = (
    args: { job: number | { id: number }; phase: number | { id: number } } | [job: number | { id: number }, phase: number | { id: number }],
    options?: RouteQueryOptions,
): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

const destroyForm = (
    args: { job: number | { id: number }; phase: number | { id: number } } | [job: number | { id: number }, phase: number | { id: number }],
    options?: RouteQueryOptions,
): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        },
    }),
    method: 'post',
})

destroyForm.delete = (
    args: { job: number | { id: number }; phase: number | { id: number } } | [job: number | { id: number }, phase: number | { id: number }],
    options?: RouteQueryOptions,
): RouteFormDefinition<'post'> => destroyForm(args, options)

destroy.form = destroyForm

const phases = {
    destroy: Object.assign(destroy, destroy),
}

export default phases
