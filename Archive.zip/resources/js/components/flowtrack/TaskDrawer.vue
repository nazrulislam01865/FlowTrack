<script setup lang="ts">
import { router, useForm } from '@inertiajs/vue3';
import { computed, ref, watch } from 'vue';
import FlowBadge from './FlowBadge.vue';
import FlowDrawer from './FlowDrawer.vue';
import FlowModal from './FlowModal.vue';
import { dueClass, formatDate, initials, records } from '@/lib/flowtrack';

const props = defineProps<{ open: boolean; taskId: number | null; options: any }>();
const emit = defineEmits<{ close: [] }>();
const task = ref<any>(null);
const loading = ref(false);
const deleteOpen = ref(false);
const deleting = ref(false);
const canUpdate = computed(() => Boolean(task.value?.can_update));
const canAssign = computed(() => Boolean(task.value?.can_assign));
const canDelete = computed(() => Boolean(task.value?.can_delete));
const canChangeDueDate = computed(() => Boolean(task.value?.can_change_due_date));
const form = useForm({
    task_status_id: null as number | null,
    assignee_id: null as number | null,
    progress: 0,
    attention_required: false,
    blocker_reason: '',
    completed_checklist_ids: [] as number[],
    comment: '',
});
const dueForm = useForm({ due_date: '' });

watch(
    () => [props.open, props.taskId],
    async ([open, id]) => {
        if (!open || !id) return;
        loading.value = true;
        deleteOpen.value = false;
        try {
            const response = await fetch(`/flowtrack/tasks/${id}`, { headers: { Accept: 'application/json' } });
            if (!response.ok) throw new Error('Unable to load task.');
            task.value = await response.json();
            form.task_status_id = task.value.task_status_id;
            form.assignee_id = task.value.assignee_id;
            form.progress = task.value.progress;
            form.attention_required = task.value.attention_required;
            form.blocker_reason = task.value.blocker_reason || '';
            form.completed_checklist_ids = task.value.checklist_items.filter((item: any) => item.is_completed).map((item: any) => item.id);
            form.comment = '';
            dueForm.due_date = String(task.value.due_date || '').slice(0, 10);
            form.clearErrors();
            dueForm.clearErrors();
        } finally {
            loading.value = false;
        }
    },
);

function statusMatches(status: any, values: string[]): boolean {
    const allowed = values.map((value) => value.trim().toUpperCase());
    return allowed.includes(String(status?.code || '').trim().toUpperCase())
        || allowed.includes(String(status?.name || '').trim().toUpperCase());
}

function progressForStatus(statusId: number | null): number {
    const status = records(props.options, 'task_status').find((item: any) => Number(item.id) === Number(statusId));
    if (statusMatches(status, ['CMP', 'COMPLETED', 'COMPLETE', 'DONE'])) return 100;
    if (statusMatches(status, ['WC', 'WAITING FOR CLIENT', 'WS', 'WAITING FOR SUPPLIER', 'WIA', 'WAITING FOR INTERNAL APPROVAL', 'WAITING FOR INTERNAL REVIEW'])) return 65;
    if (statusMatches(status, ['IP', 'IN PROGRESS', 'BLK', 'BLOCKED', 'ATTN', 'ATTENTION', 'HOLD', 'ON HOLD'])) return 50;
    if (statusMatches(status, ['REV', 'REVISION REQUIRED'])) return 35;
    if (statusMatches(status, ['READY'])) return 10;
    return 0;
}

watch(
    () => form.task_status_id,
    (statusId) => {
        form.progress = progressForStatus(statusId);
    },
);

function save() {
    if (!task.value) return;
    form.put(`/flowtrack/tasks/${task.value.id}`, {
        preserveScroll: true,
        onSuccess: () => {
            emit('close');
            router.reload();
        },
    });
}

function saveDueDate() {
    if (!task.value || !canChangeDueDate.value) return;
    dueForm.patch(`/flowtrack/tasks/${task.value.id}/due-date`, {
        preserveScroll: true,
        onSuccess: () => {
            task.value.due_date = dueForm.due_date || null;
            router.reload();
        },
    });
}

function deleteTask() {
    if (!task.value || !canDelete.value) return;
    deleting.value = true;
    router.delete(`/flowtrack/tasks/${task.value.id}`, {
        preserveScroll: true,
        onSuccess: () => {
            deleteOpen.value = false;
            emit('close');
            router.reload();
        },
        onFinish: () => {
            deleting.value = false;
        },
    });
}
</script>

<template>
    <FlowDrawer :open="open" @close="emit('close')">
        <div class="ft-drawer-head">
            <div v-if="task"><div class="ft-muted ft-small">{{ task.code }} · {{ task.job?.code }}</div><h2 style="font-size: 18px; margin: 4px 0">{{ task.title }}</h2><FlowBadge :value="task.status?.name" /> <FlowBadge :value="task.priority?.name" /></div>
            <div class="ft-actions"><button v-if="canDelete" class="ft-danger" @click="deleteOpen = true">Delete Task</button><button class="ft-close-btn" @click="emit('close')">×</button></div>
        </div>
        <div class="ft-drawer-body">
            <div v-if="loading" class="ft-empty">Loading task…</div>
            <template v-else-if="task">
                <div class="ft-summary-grid">
                    <div class="ft-summary-box"><span>Job</span><b>{{ task.job?.title }}</b></div>
                    <div class="ft-summary-box"><span>Assignee</span><b>{{ task.assignee?.name || 'Unassigned' }}</b></div>
                    <div class="ft-summary-box"><span>Due Date</span><b class="ft-due" :class="dueClass(task.due_date)">{{ formatDate(task.due_date) }}</b></div>
                    <div class="ft-summary-box"><span>Workflow Phase</span><b>{{ task.phase?.name || 'General' }}</b></div>
                    <div class="ft-summary-box"><span>Parent Task</span><b>{{ task.parent?.code || 'None' }}</b></div>
                    <div class="ft-summary-box"><span>Dependency</span><b>{{ task.dependency?.code || 'None' }}</b></div>
                </div>
                <div v-if="task.start_rule" class="ft-source-note"><b>Start rule:</b> {{ task.start_rule }}</div>
                <div class="ft-form-grid" style="margin-top: 18px">
                    <div class="ft-field"><label>Status</label><select v-model.number="form.task_status_id" :disabled="!canUpdate"><option v-for="status in records(options, 'task_status')" :key="status.id" :value="status.id">{{ status.name }}</option></select></div>
                    <div class="ft-field"><label>Assignee</label><select v-model.number="form.assignee_id" :disabled="!canAssign"><option :value="null">Unassigned</option><option v-for="user in options.users" :key="user.id" :value="user.id">{{ user.name }}</option></select></div>
                    <div class="ft-field"><label>Due date</label><input v-model="dueForm.due_date" type="date" :disabled="!canChangeDueDate" /><span v-if="dueForm.errors.due_date" class="ft-error">{{ dueForm.errors.due_date }}</span><div v-if="canChangeDueDate" class="ft-help">Applies to regular tasks and subtasks.</div></div>
                    <div class="ft-field" style="display:flex;align-items:flex-end"><button v-if="canChangeDueDate" class="ft-secondary" style="width:100%" :disabled="dueForm.processing" @click="saveDueDate">{{ dueForm.processing ? 'Saving…' : 'Save Due Date' }}</button></div>
                    <div class="ft-field full"><label>Progress: <b>{{ form.progress }}%</b></label><input v-model.number="form.progress" type="range" min="0" max="100" disabled /><div class="ft-help">Progress updates automatically from the selected status.</div></div>
                </div>
                <div class="ft-section-head"><h3>Checklist</h3><span class="ft-muted ft-small">{{ form.completed_checklist_ids.length }}/{{ task.checklist_items.length }} complete</span></div>
                <label v-for="item in task.checklist_items" :key="item.id" class="ft-check-row"><input v-model="form.completed_checklist_ids" type="checkbox" :value="item.id" :disabled="!canUpdate" /> {{ item.label }}</label>
                <div class="ft-field" style="margin-top: 18px"><label>Blocker / attention reason</label><textarea v-model="form.blocker_reason" rows="3" :disabled="!canUpdate" placeholder="Required when the task is blocked or attention is needed"></textarea><span v-if="form.errors.blocker_reason" class="ft-error">{{ form.errors.blocker_reason }}</span></div>
                <label class="ft-check-row"><input v-model="form.attention_required" type="checkbox" :disabled="!canUpdate" /> Mark as attention needed</label>
                <div class="ft-field" style="margin-top: 18px"><label>Update comment</label><textarea v-model="form.comment" rows="3" :disabled="!canUpdate" placeholder="Add progress, a decision, blocker, or next action"></textarea></div>
                <div class="ft-section-head" style="margin-top: 18px"><h3>Activity & Comments</h3></div>
                <div v-for="comment in task.comments" :key="comment.id" class="ft-comment"><span class="ft-avatar">{{ comment.user?.initials || initials(comment.user?.name) }}</span><div><b>{{ comment.user?.name || 'System' }}</b><div style="margin-top: 4px">{{ comment.body }}</div><div class="ft-muted ft-small" style="margin-top: 4px">{{ new Date(comment.created_at).toLocaleString() }}</div></div></div>
                <div v-if="!canUpdate" class="ft-source-note" style="margin-top: 18px"><b>Limited Task Access</b><div class="ft-help" style="margin-top: 4px">Everyone assigned to this Job can view its Tasks. Full Task updates remain limited to the assignee or an Administrator; authorized Job managers can still change the due date.</div></div>
                <button v-if="canUpdate" class="ft-primary" style="width: 100%; margin-top: 18px" :disabled="form.processing" @click="save">{{ form.processing ? 'Saving…' : 'Save Task Update' }}</button>
            </template>
        </div>
    </FlowDrawer>

    <FlowModal :open="deleteOpen" title="Delete this Task?" subtitle="The task will be removed from this Job and will not be regenerated automatically." @close="deleteOpen = false">
        <div class="ft-card" style="padding: 16px; border-color: #fecaca; background: #fff7f7"><div class="ft-muted ft-small">{{ task?.code }}</div><h3 style="margin: 5px 0 8px">{{ task?.title }}</h3><div class="ft-small">Checklist items, comments and generated task links connected to this task will no longer appear in the Job.</div></div>
        <template #footer><button class="ft-ghost" @click="deleteOpen = false">Keep Task</button><button class="ft-danger" :disabled="deleting" @click="deleteTask">{{ deleting ? 'Deleting…' : 'Delete Task' }}</button></template>
    </FlowModal>
</template>
