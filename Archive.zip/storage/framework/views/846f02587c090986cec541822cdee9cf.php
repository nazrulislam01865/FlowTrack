<?php echo $__env->make('flowtrack.partials.runtime-defaults', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<title>FlowTrack — Promotional Products Workflow Prototype</title>
<link id="flowtrackFavicon" rel="icon" href="<?php echo e($flowtrackBranding['faviconUrl'] ?? asset('favicon.ico')); ?>" />
<?php echo app('Illuminate\Foundation\Vite')('resources/css/flowtrack/app.css'); ?>
</head>
<body class="<?php echo e($flowtrackAuthenticated ? 'flowtrack-booting' : ''); ?>">
<?php echo $__env->make('flowtrack.auth.login', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('flowtrack.auth.loading', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('flowtrack.layouts.workspace', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('flowtrack.partials.overlays', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('flowtrack.partials.assets', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowline/resources/views/flowtrack-template.blade.php ENDPATH**/ ?>